(Demo.Routes = function($, jQuery){

    function _setNavBackAndHome(){
        $.UI.setLeftNav("Back")
            .setRightNav("Home", "index.html");
    }

    function _errorOccurred(e) {
        switch (e.code)
        {
        case e.INVALID_VALUES_ERR:
            alert(e.code + ":" + e.message + "\nThe successCallback does not contains a function.");
            break;

        case e.NOT_SUPPORTED_ERR:
            alert(e.code + ":" + e.message + "\nThis feature is not supported.");
            break;

        case e.SECURITY_ERR:
            alert(e.code + ":" + e.message + "\nThis functionality is not allowed.");
            break;

        default: // e.UNKNOWN_ERR
            alert(e.code + ":" + e.message);
            break;
        }
    }

    function _catchException(e) {
        switch (e.code)
        {
        case e.TYPE_MISMATCH_ERR:
            alert(e.code + ":" + e.message + "\nInput parameters are not compatible with the expected type for that parameter.");
            break;
            
        default: // e.UNKNOWN_ERR
            alert(e.code + ":" + e.message);
            break;
        }
    }

    // ----- Private Vars -----
    var _baseUrl = "",
        _history = [],
        _routes = {

            "index.html": function(){

                $.Routes.clearHistory();

                $.UI.setLeftNav()
                    .setTitle("Demo")
                    .setRightNav();

            },

            "accelerometer.html": function(){
                _setNavBackAndHome();
                
                var inputX = jQuery("#accelerometer-x-axis"),
                    inputY = jQuery("#accelerometer-y-axis"),
                    inputZ = jQuery("#accelerometer-z-axis"),
                    idWatch = 0,
                    shakeValue = 0;

                function updateAcceleration(acceleration) {
                    var myXaxis = acceleration.xAxis,
                        myYaxis = acceleration.yAxis,
                        myZaxis = acceleration.zAxis,
                        newAccelerometerData = "";

                    inputX.val(myXaxis);
                    inputY.val(myYaxis);
                    inputZ.val(myZaxis);

                    if (myXaxis > 10 || myXaxis < -10 || myYaxis > 10 || myYaxis < -10 || myZaxis > 10 || myZaxis < -10) {
                        // Increase the value so less shaking is needed to reach a shaking detection
                        shakeValue += 2;
                    }
                    else {
                        if (shakeValue > 0) {
                            shakeValue -= 1;
                        }
                    }

                    newAccelerometerData += '<br>';
                    if (shakeValue > 10) {
                        newAccelerometerData += 'User is shaking? YES';
                    }
                    else {
                        newAccelerometerData += 'User is shaking? NO';
                    }
                    jQuery("#accelerometer-shake-status").html(newAccelerometerData);
                }

                jQuery("#accelerometer-get").unbind().bind("mousedown", function () {
                    try {
                        var pendingOperation = null;

                        pendingOperation = deviceapis.accelerometer.getCurrentAcceleration(updateAcceleration, _errorOccurred);

                        if (pendingOperation != null) {
                            if (confirm("Are you sure want to cancel the operation")) {
                                if (pendingOperation.cancel()) {
                                    alert("pending operation is cancelled");
                                }
                                else {
                                    alert("pending operation can not be cancelled");
                                }
                            }
                        }
                    }
                    catch (e) {
                        _catchException(e);
                    }
                });

                jQuery("#accelerometer-watch").unbind().bind("mousedown", function () {
                    try {
                        if (idWatch != 0)
                            return;
                        idWatch = deviceapis.accelerometer.watchAcceleration(updateAcceleration, _errorOccurred,
                            {minNotificationInterval: 100});
                    }
                    catch (e) {
                        _catchException(e);
                    }
                });

                jQuery("#accelerometer-clear").unbind().bind("mousedown", function () {
                    try {
                        if (idWatch == 0)
                            return;
                        deviceapis.accelerometer.clearWatch(idWatch);
                        idWatch = 0;
                    }
                    catch (e) {
                        _catchException(e);
                    }
                });
            },
            
            "orientation.html": function(){
                _setNavBackAndHome();

                var inputAlpha = jQuery("#orientation-alpha"),
                    inputBeta  = jQuery("#orientation-beta"),
                    inputGamma = jQuery("#orientation-gamma"),
                    idWatch = 0,
                    newOrientation = '',
                    oldOrientation = '';

                function updateOrientation(rotation) {
                    azimuth = rotation.alpha;
                    pitch = rotation.beta;
                    roll = rotation.gamma;

                    inputAlpha.val(azimuth);
                    inputBeta.val(pitch);
                    inputGamma.val(roll);

                    if (pitch < -45) {
                        if(pitch > -135)
                            newOrientation = 'Bottom';
                    }
                    else if (pitch > 45) {
                        if (pitch < 135)
                            newOrientation = 'Top';
                    }
                    else if (roll > 45) {
                        newOrientation = 'Right';
                    }
                    else if (roll < -45) {
                        newOrientation = 'Left';
                    }
                    else {
                        newOrientation = 'Flat';
                    }

                    if (newOrientation != oldOrientation) {
                        oldOrientation = newOrientation;
                        jQuery("#orientation-status").html("Current Orientation: " + newOrientation);
                    }
                }

                function captureScreenDimensionChange(width, height) {
                    var message = "JIL :: onScreenChangeDimensions was called. <br />" +
                                    "Width ==> " + width + " Height ==> " + height;
                    _notifyEventWasCalled(message);
                }

                jQuery("#orientation-get").unbind().bind("mousedown", function () {
                    try {
                        var pendingOperation = null;

                        pendingOperation = deviceapis.orientation.getCurrentOrientation(updateOrientation, _errorOccurred);

                        if (pendingOperation != null) {
                            if (confirm("Are you sure want to cancel the operation")) {
                                if (pendingOperation.cancel()) {
                                    alert("pending operation is cancelled");
                                }
                                else {
                                    alert("pending operation can not be cancelled");
                                }
                            }
                        }
                    }
                    catch (e) {
                        _catchException(e);
                    }
                });

                jQuery("#orientation-watch").unbind().bind("mousedown", function () {
                    try {
                        if (idWatch != 0)
                            return;
                        idWatch = deviceapis.orientation.watchOrientation(updateOrientation, _errorOccurred,
                            {minNotificationInterval: 100});
                    }
                    catch (e) {
                        _catchException(e);
                    }
                });

                jQuery("#orientation-clear").unbind().bind("mousedown", function () {
                    try {
                        if (idWatch == 0)
                            return;
                        deviceapis.orientation.clearWatch(idWatch);
                        idWatch = 0;
                    }
                    catch (e) {
                        _catchException(e);
                    }
                });
            },
            
            "deviceapis.html": function(){
                _setNavBackAndHome();

                var paramBtnIds = [];
                // As no params in current features, so these two functions hasn't been tested
                function createParamTable(params, featureName) {
                    var paramHtml = '', index, foldImage = "images/arrow_down.png", unfoldImage = "images/arrow_right.png",
                        imageHtml = '<div class="ds_ui_btn"><center><img src=' + foldImage + ' width="24" height="24" id="' + featureName + '_btn"></center></div>';
                        paraHeadHtml = '<tr><td width="30%"><table border="0" width="100%"><tr><td width="80%" style="font-weight: bold;">Param</td><td width="20%">' + 
                                        imageHtml + '</td><tr></table></td><td width="35%">Name</td><td width="35%">Value</td></tr>';
                    
                    paramBtnIds.push(featureName);
                    for (index = 0; index < params.length; index++) {
                        paramHtml += '<tr class="' + featureName + '_params"><td width="30%">&nbsp</td><td width="35%">' +
                                     params[index].name + '</td><td width="35%">' + params[index].value + '</td></tr>';
                        paramBtnIds.push(btnId);
                    }

                    return paraHeadHtml + paramHtml;
                }
                
                function bindParamBtn() {
                    var index = 0;
                    for (index = 0; index < paramBtnIds.length; index++) {
                        jQuery("#" + paramBtnIds[index] + '_btn').unbind().bind("click", function () {
                            jQuery("." + paramBtnIds[index] + '_params').toggle();
                        });
                    }
                }

                function getFeatureMap(featureList) {
                    // key --> featureArray, divide featureList into some groups 
                    var featureMap = {}, mapKey = '', featureName = '', featureNameElements = [], index, uri = ''; 

                    for (index = 0; index < featureList.length; index++) {
                        uri = featureList[index].uri;
                        if (uri.charAt(uri.length-1) === '/') {
                            uri = uri.substr(0, uri.length-1);
                        }
                        featureName = uri.split("/").pop(); 
                        featureNameElements = featureName.split(".");                        
                        if (featureNameElements.length === 1 || featureNameElements.length === 2) {
                            mapKey = featureNameElements[0];
                        }
                        else if (featureNameElements.length === 3) {
                            mapKey = featureNameElements[0] + '.' + featureNameElements[1];
                        }

                        if (featureMap[mapKey] instanceof Array !== true) {      
                            featureMap[mapKey] = [];                                                  
                        }
                        featureMap[mapKey].push(featureList[index]);                      
                    }
                    return featureMap;                    
                }
                
                function createItem(featureTittle, featureList) {
                    var itemHeadHtml = '<table id="' + featureName + '" class="datatable" width="100%" cellspacing="0" cellpadding="3" style="border: 1px;">' +
                                            '<tr><th colspan=2>' + featureTittle + '</th></tr>',
                        itemContentHtml = '', rowColor, featureName = '', isRequired = false, params = [], index,
                        itemTailHtml = '</table>', style = ''; 
 
                    for (index = 0; index < featureList.length; index++ ) {
                        if (index % 2) {
                			rowColor = "eeeeee";
                		}
                		else {
                			rowColor = "ffffff";
                		}

                        featureName = featureList[index].uri.split('/').pop();
                        if (featureList.length === 1) {
                            style = "DISPLAY:none;";
                        }
                        else {
                            style = "font-weight: bold;";
                        }

                        itemContentHtml += '<tr style="' + style + '"><td width="100%" colspan=2><center>' + featureName + '</center></td></tr>' +
                                                '<tr><td width="30%" style="font-weight: bold;">URI     </td><td width="70%">' + featureList[index].uri + '</td></tr>' +
                                                '<tr><td width="30%" style="font-weight: bold;">Required</td><td width="70%">' + featureList[index].required + '</td></tr>';
                        if (featureList[index].params) {
                            itemContentHtml += createParamTable(featureList[index].params, featureName);
                        }
                    }


                    return itemHeadHtml + itemContentHtml + itemTailHtml;
                }
                
                function createFeatureList(featureMap) {
                    var featureListHtml = '';
                    for (var key in featureMap) {
                        featureListHtml += createItem(key, featureMap[key]);
                    }
                    return featureListHtml;
                }

                try {
                    var availableFeatures = deviceapis.listAvailableFeatures(), 
                        availableFeaturesHtml, 
                        activatedFeatures = deviceapis.listActivatedFeatures(),
                        activatedFeaturesHtml;

                    if (availableFeatures) {
                        availableFeaturesHtml = createFeatureList(getFeatureMap(availableFeatures));
                        jQuery("#available-features-list").html(availableFeaturesHtml);
                        bindParamBtn();
                    }
                    
                    if (activatedFeatures) {
                        activatedFeaturesHtml = createFeatureList(getFeatureMap(activatedFeatures));
                        jQuery("#activated-features-list").html(activatedFeaturesHtml);
                        bindParamBtn();
                    }                    
                }
                catch (e) {
                    _catchException(e);
                }     
            },
            
            "geolocation.html": function(){
                _setNavBackAndHome();

                var timestamp = jQuery("#position-timestamp");
                    longitude = jQuery("#position-longitude"),
                    latitude = jQuery("#position-latitude"),
                    altitude = jQuery("#position-altitude"),
                    accuracy = jQuery("#position-accuracy"),
                    altitudeAccuracy = jQuery("#position-altitudeAccuracy"),
                    heading = jQuery("#position-heading"),
                    speed = jQuery("#position-speed")
                    idWatch = 0;

                function updatePosition(position) {
                    timestamp.val(position.timestamp);
                    longitude.val(position.coords.longitude);
                    latitude.val(position.coords.latitude);
                    altitude.val(position.coords.altitude);
                    accuracy.val(position.coords.accuracy);
                    altitudeAccuracy.val(position.coords.altitudeAccuracy);
                    heading.val(position.coords.heading);
                    speed.val(position.coords.speed);
                }

                jQuery("#position-get").unbind().bind("mousedown", function () {
                    try {
                        navigator.geolocation.getCurrentPosition(updatePosition, _errorOccurred);                       
                    }
                    catch (e) {
                        _catchException(e);
                    }
                });

                jQuery("#position-watch").unbind().bind("mousedown", function () {
                    try {
                        idWatch = navigator.geolocation.watchPosition(updatePosition, _errorOccurred);
                    }
                    catch (e) {
                        _catchException(e);
                    }
                });

                jQuery("#position-clear").unbind().bind("mousedown", function () {
                    try {
                        navigator.geolocation.clearWatch(idWatch);
                        idWatch = 0;
                    }
                    catch (e) {
                        _catchException(e);
                    }
                });
            },
			"messaging.html": function () {
                _setNavBackAndHome();

                var msg_type = jQuery("#messaging-type"),
                    msg_to = jQuery("#messaging-to"),
                    msg_text = jQuery("#messaging-text"),
                    messageSendCallback = {
                        onsuccess: function () {
                            //alert("The message has been sent to all the recipients.");
                        },
                        onmessagesendsuccess: function (recipient) {
                            //alert("The message has been sent to " + recipient);
                        },
                        onmessagesenderror: function (error, recipient) {
                            //alert("The message has not been sent to " + recipient + "\nError: " + error);
                        }
                    },
                    smsListener = null,
                    mmsListener = null,
                    emailListener = null;

                function messageSent() {
                    alert("The message has been sent successfully.");
                }

                function incomingSMS(message) {
                    alert("New incoming SMS from " + message.from);
                    jQuery("#received-message-box").val("Data: " + message.time + "\nFrom: " + message.from +  "\n\n" + message.body);
                }

                function incomingMMS(message) {
                    alert("New incoming MMS from " + message.from);
                    jQuery("#received-message-box").val("Data: " + message.time + "\nFrom: " + message.from +  "\n\n" + message.body);
                }

                function incomingEmail(message) {
                    alert("New incoming E-mail from " + message.from);
                    jQuery("#received-message-box").val("Data: " + message.time + "\nFrom: " + message.from +  "\n\n" + message.body);
                }
                
                
                function switchMessageForm() {
                	switch (msg_type.val()) {
                		case "sms":
                			jQuery("#message-form-messaging-cc").remove();
                			jQuery("#message-form-messaging-bcc").remove();
                			break;
                		case "mms":
                			jQuery("#message-form-messaging-cc").remove();
                			jQuery("#message-form-messaging-bcc").remove();
                			break;
                		case "email":
                			jQuery("#message-form > tbody > tr").eq(1).after('<tr id="message-form-messaging-cc"><td>Cc :</td><td><input type="text" id="messaging-cc"/></td></tr>');
                			jQuery("#message-form > tbody > tr").eq(2).after('<tr id="message-form-messaging-bcc"><td>Bcc :</td><td><input type="text" id="messaging-bcc"/></td></tr>');
                			break;
                	}
                }
				
				
				function subscribeMessage(subscribe_msg_type) {
					try {
                        switch (subscribe_msg_type) {
                        case "sms":
                            if (smsListener === null)
                                smsListener = deviceapis.messaging.onSMS(incomingSMS);
                            break;

                        case "mms":
                            if (mmsListener === null)
                                mmsListener = deviceapis.messaging.onMMS(incomingMMS);
                            break;

                        case "email":
                            if (emailListener === null)
                                emailListener = deviceapis.messaging.onEmail(incomingEmail);
                            break;
                        }
                    }
                    catch (e) {
                        _catchException(e);
                    }
				}
				
				function unsubscribeMessage(unsubscribe_msg_type) {
					try {
                        switch (unsubscribe_msg_type) {
                        case "sms":
                            if (smsListener !== null) {
                                deviceapis.messaging.unsubscribe(smsListener);
                                smsListener = null;
                            }
                            break;

                        case "mms":
                            if (mmsListener !== null) {
                                deviceapis.messaging.unsubscribe(mmsListener);
                                mmsListener = null;
                            }
                            break;

                        case "email":
                            if (emailListener !== null) {
                                deviceapis.messaging.unsubscribe(emailListener);
                                emailListener = null;
                            }
                            break;
                        }
                    }
                    catch (e) {
                        _catchException(e);
                    }
				}
				
                jQuery("#messaging-send").unbind().bind("click", function () {
                    try {
                        var msgType;

                        switch (msg_type.val()) {
                        case "sms":
                            msgType = deviceapis.messaging.TYPE_SMS;
                            break;

                        case "mms":
                            msgType = deviceapis.messaging.TYPE_MMS;
                            break;

                        case "email":
                            msgType = deviceapis.messaging.TYPE_EMAIL;
                            break;
                        }
                        var msg = deviceapis.messaging.createMessage(msgType);
                        msg.body = msg_text.val();
                        msg.to = msg_to.val().split(/[;,]\s*/);
                        
                        if (msgType == "email") {
                        	msg.cc = jQuery("#messaging-cc").val().split(/[;,]\s*/);
                        	msg.bcc = jQuery("#messaging-bcc").val().split(/[;,]\s*/);
                        }
                        
                        if (msg.to.length + msg.cc.length + msg.bcc.length === 1) {
                            deviceapis.messaging.sendMessage(messageSent, _errorOccurred, msg);
                        }
                        else {
                            deviceapis.messaging.sendMessage(messageSendCallback, _errorOccurred, msg);
                        }
                        
                        msg_text.val("");
                        msg_to.val("");
                        jQuery("#messaging-cc").val("");
                        jQuery("#messaging-bcc").val("")
                    }
                    catch (e) {
                        _catchException(e);
                    }
                });

				
                jQuery("#sms-subscribe").unbind().bind("mousedown", function () {
                    subscribeMessage("sms");
                });
                
                jQuery("#mms-subscribe").unbind().bind("mousedown", function () {
                    subscribeMessage("mms");
                });
                
                jQuery("#email-subscribe").unbind().bind("mousedown", function () {
                    subscribeMessage("email");
                });

                jQuery("#sms-unsubscribe").unbind().bind("mousedown", function () {
                   unsubscribeMessage("sms");
                });
                
                jQuery("#mms-unsubscribe").unbind().bind("mousedown", function () {
                   unsubscribeMessage("mms");
                });
                
                jQuery("#email-unsubscribe").unbind().bind("mousedown", function () {
                   unsubscribeMessage("email");
                });
                
                jQuery("#messaging-clear").unbind().bind("click", function () {
                    try {
                        jQuery("#received-message-box").val("");
                    }
                    catch (e) {
                        _catchException(e);
                    }
                });
                
                jQuery("#messaging-type").unbind().bind("change", function () {
                    try {
                        switchMessageForm();
                    }
                    catch (e) {
                        _catchException(e);
                    }
                });
            },
            "task.html": function() {
                _setNavBackAndHome();

                var _taskLists,
                    listNumber = 0,
                    taskTmp = {},
                    listName, list,
                    taskFilter = { status : [1]},
                    pendop = null;

                /* list tasks */
                function listTasks() {

                    if (listNumber >=_taskLists.length) {
                        alert("task : list error");
                        return;
                    }

                    try {
                        pendop = null;
                        pendop = _taskLists[listNumber].findTasks(getTasksCB, _errorOccurred, taskFilter);
		    } catch(e) {
		        _catchException(e);
		        pendop = null;
		    }

	            function getTasksCB(tasks) {
	                list = tasks;
	                showTaskHTML(list);
                    }
                }

                /* show HTML */
                function showTaskHTML(nodes) {
                    var row_color;
                    var str = "";
                    var d;
                    str += '<table cellpadding="5" width="100%" border="0" cellspacing="0">\n'+
                        '<tr class="list_head"><th width="10%">&nbsp;</th><th width="75%">Summary</th><th>Priority</th></tr>';
                    for (var i = 0; i < nodes.length; i++) {
                        if (i%2) {
                            row_color = "eeeeee";
                        }
                        else {
                            row_color = "ffffff";
                        }
	                str += "<tr style='background-color:#" + row_color + "' id='"+ nodes[i].id;
	                str += "'><td align='center'><input type='checkbox' name='task_ui_status' id='task_ui_status'";
	                if (nodes[i].status === 0)
	                    str += "checked";
	                str += " value=1></td><td id='taskCB'><div class='taskSummary'>";
	                str += nodes[i].summary;
	                str += "</div><div class='taskDate'>";
                        d = nodes[i].dueDate;
	                if (Object.prototype.toString.call(d) === "[object Date]" )
	                    str += d.toDateString();
	                str += "</div></td><td id='taskCB' align='center'><div>";
	                switch(nodes[i].priority) {
                            case 0:
                                str += "<p style='color:red'>HIGH</p>";
                                break;
                            case 1:
                                str += "MEDIUM";
                                break;
                            case 2:
                                str += "<p style='color:grey'>LOW</p>";
                                break;
                        };
	                str += "</div>"

	                str += "</td></tr>";
                    }
	            str += "</table>";
                    jQuery("#available-tasks-list").html(str);
                    jQuery("#task_ui_total").html("Total: " + i + " task(s)");
                }

                /* TASK DEMO initial. Get TaskLists */
                function taskDemoInit() {
                    try {
                        pendop = null;
                        pendop = deviceapis.pim.task.getTaskLists(
		              getListsCB, _errorOccurred);
                    }
                    catch (e) {
                        _catchException(e);
                        pendop = null;
                    }

                    function getListsCB (lists) {
                        _taskLists = lists;
                        listTasks();
                        jQuery("#task_ui_main").hide();
                        jQuery("#task_ui_main").show("fast");
                    }
                }

                /* == task DEMO start point == */
                taskDemoInit();

                /* event-hadle: tasklist select change */
                jQuery("#task-list").unbind().bind("change" , function () {
                    switch (jQuery("#task-list").val()) {
                        case "0": // task needs action
                            taskFilter = { status : [1]};
                            break;
                        case "1": // completed
                            taskFilter = { status : [0]};
                            break;
                    }
                    listTasks();
                });

                /* event-handle: task remind (dueDate) */
                jQuery("#task_ui_remind").unbind().bind("change" , function (e, date) {
                    var str1 = "" ,str2 = "", i = 0;

                    if (jQuery("#task_ui_remind").attr("checked")) {
                        str1 += "<td>&nbsp;</td><td><select id='task_ui_year'>";
                        for(i = 0; i < 4; i++) {
                            str1 += "<option value=" + String(2011+i) + ">" + String(2011+i) + "</option>";
                        }
                        str1 += "</select> - <select id='task_ui_month'>";
                        for(i = 0; i < 12; i++) {
                            str1 += "<option value=" + String(i) + ">" + String(1+i) + "</option>";
                        }
                        str1 += "</select> - <select id='task_ui_day'>";
                        for(i = 0; i < 31; i++) {
                            str1 += "<option value=" + String(1+i) + ">" + String(1+i) + "</option>";
                        }
                        str1 += "</select>";

                        str2 += "<td>&nbsp;</td><td><select id='task_ui_hour'>";
                        for (i = 0; i <= 23; i++) {
                            str2 += "<option value=" + String(i) + ">" + String(i) + "</option>";
                        }
                        str2 += "</select> : <select id='task_ui_min'>";
                        for (i = 0; i <= 59; i++) {
                            str2 += "<option value=" + String(i) + ">" + String(i) + "</option>";
                        }
                    }
                    jQuery("#task_ui_dueDate1").html(str1);
                    jQuery("#task_ui_dueDate2").html(str2);
                    if (Object.prototype.toString.call(date) !== "[object Date]")
                        date = new Date();
                    jQuery("#task_ui_year").val(date.getFullYear());
                    jQuery("#task_ui_month").val(date.getMonth());
                    jQuery("#task_ui_day").val(date.getDate());
                    jQuery("#task_ui_hour").val(date.getHours());
                    jQuery("#task_ui_min").val(date.getMinutes());

                });

                /* event-handle: change the task status */
                jQuery("#task_ui_status").live("change", function () {
                    var item = jQuery(this).parent().parent(), i = 0, id;
                    id = item[0].id;
                    for ( i = 0; i < list.length; i++) {
                        if (list[i].id === id) {
                            jQuery(this).attr("checked") ? list[i].status = 0 : list[i].status = 1;
                            taskTmp = list[i];
                            try {
                                pendop = null;
                                pendop = _taskLists[listNumber].updateTask(function () {listTasks();}, _errorOccurred, taskTmp);
		            } catch(e) {
		                _catchException(e);
		                pendop = null;
                            }
                            break;
                        }
                    }
                });

                /* event-handle: show the specific task detail */
                jQuery("#taskCB").live("mousedown", function () {
                    jQuery("#task_ui_task_form_title").text("Edit Task");
                    var item = jQuery(this).parent(), i = 0, id;
                    id = item[0].id;
                    for (i = 0; i < list.length; i++) {
                        if (list[i].id === id) {
                            jQuery("#task-id").val(id);
                            jQuery("#task-summary").val(list[i].summary);
                            jQuery("#task-description").val(list[i].description);
                            jQuery("#task-priority").val(list[i].priority);
                            jQuery("#task-status").val(list[i].status);

	                    if (Object.prototype.toString.call(list[i].dueDate) === "[object Date]" ) {
                                jQuery("#task_ui_remind").attr("checked", true).trigger("change", [list[i].dueDate]);
                            } else {
                                jQuery("#task_ui_remind").attr("checked", false).trigger("change");
                            }
                        }
                    }
                    jQuery("#task-update-button").show();
                    jQuery("#task-delete-button").show();
                    jQuery("#task-add-button").hide();
                    jQuery("#task_ui_main").hide();
                    jQuery("#task_ui_detail").show("fast");
                });

                /* event-handle: hide the detail */
                jQuery("#task-cancel-button").unbind().bind("mousedown" , function () {
                    jQuery("#task_ui_main").show();
                    jQuery("#task_ui_detail").hide();
                });

                /* event-handle: create a task */
                jQuery("#task_ui_new").unbind().bind("mousedown", function () {
                    try {
                        taskTmp = _taskLists[listNumber].createTask({}); 
                    } catch (e) {
                        alert("create task fail:\n" + e);
                        return;
                    }

                    jQuery("#task_ui_task_form_title").text("Add Task");
                    jQuery("#task-update-button").hide();
                    jQuery("#task-delete-button").hide();
                    jQuery("#task-add-button").show();
                    jQuery("#task-id").val(taskTmp.id);
                    jQuery("#task-summary").val(taskTmp.summary);
                    jQuery("#task-priority").val(taskTmp.priority);
                    jQuery("#task-status").val(taskTmp.status);
                    jQuery("#task-description").val(taskTmp.description);
                    jQuery("#task_ui_remind").attr("checked", false).trigger("change");

                    jQuery("#task_ui_main").hide();
                    jQuery("#task_ui_detail").show("fast");
                });

                /* event-handle: add a task */
                jQuery("#task-add-button").unbind().bind("mousedown", function () {
                    taskTmp = {};
                    taskTmp.summary = jQuery("#task-summary").val();
                    taskTmp.priority = parseInt( jQuery("#task-priority").val(), 10 );
                    taskTmp.status = parseInt( jQuery("#task-status").val(), 10 );
                    taskTmp.description = jQuery("#task-description").val();
                    if (jQuery("#task_ui_remind").attr("checked")) {
                        y = jQuery("#task_ui_year").val();
                        m = jQuery("#task_ui_month").val();
                        d = jQuery("#task_ui_day").val();
                        h = jQuery("#task_ui_hour").val();
                        min = jQuery("#task_ui_min").val();
                        taskTmp.dueDate = new Date(y, m, d, h, min);
                    } else {
                        taskTmp.dueDate = undefined;
                    }

                    try {
                        pendop = null;
                        pendop = _taskLists[listNumber].addTask(taskAddSuccessCB, _errorOccurred, taskTmp);
		    } catch(e) {
		        _catchException(e);
		        taskTmp = {};
		        pendop = null;
                    }
                    jQuery("#task_ui_main").show();
                    jQuery("#task_ui_detail").hide();
                    listTasks();

                    function taskAddSuccessCB (task) {
                        //alert("task id: " + task.id +" added successfully");
                    };

                });

                /* event-handle: update a task */
                jQuery("#task-update-button").unbind().bind("mousedown", function () {
                    var item = jQuery(this).parent(), i = 0, id;
                    id = jQuery("#task-id").val();

                    taskTmp = undefined;
                    for (i = 0; i < list.length; i++) {
                        if (list[i].id === id) {
                            taskTmp = list[i];
                            break;
                        }
                    }

                    if (taskTmp === undefined)
                        return;

                    taskTmp.summary = jQuery("#task-summary").val();
                    taskTmp.priority = parseInt( jQuery("#task-priority").val(), 10 );
                    taskTmp.status = parseInt( jQuery("#task-status").val(), 10 );
                    taskTmp.description = jQuery("#task-description").val();
                    if (jQuery("#task_ui_remind").attr("checked")) {
                        y = jQuery("#task_ui_year").val();
                        m = jQuery("#task_ui_month").val();
                        d = jQuery("#task_ui_day").val();
                        h = jQuery("#task_ui_hour").val();
                        min = jQuery("#task_ui_min").val();
                        taskTmp.dueDate = new Date(y, m, d, h, min);
                    } else {
                        taskTmp.dueDate = undefined;
                    }

                    try {
                        pendop = null;
                        pendop = _taskLists[listNumber].updateTask(taskUpdateSuccessCB, _errorOccurred, taskTmp);
		    } catch(e) {
		        _catchException(e);
		        pendop = null;
                    }
                    jQuery("#task_ui_main").show();
                    jQuery("#task_ui_detail").hide();
                    listTasks();

                    function taskUpdateSuccessCB() {
                        //alert("'task update' successfully");
                    }
                });

                /* event-handle: delete a task */
                jQuery("#task-delete-button").unbind().bind("mousedown", function () {
                    var id = jQuery("#task-id").val();

                    try {
                        pendop = null;
                        pendop = _taskLists[listNumber].deleteTask(taskDeleteSuccessCB, _errorOccurred, id);
                    } catch(e) {
                        _catchException(e);
                        pendop = null;
                    }

                    jQuery("#task_ui_main").show();
                    jQuery("#task_ui_detail").hide();
                    listTasks();

                    function taskDeleteSuccessCB () {
                        //alert("'task delete' successfully");
                    }
                });

            },

            "calendar.html": function () {
                _setNavBackAndHome();

                var _calendarList, _events, _oneDayEvents, now, month_page, cal_y, cal_m, day_m, day_d, eventTmp,
                    calFilter = {};
                    MONTHS_S = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
		    MONTHS_L = [ "January", "February", "March", "April", "May", "June", "July", "Auguest", "September", "October", "November", "December"];

                /* list calendar */
                function listCalMain() {
                    initial = new Date(cal_y, cal_m - 1, 1, 0, 0, 0);
                    end = new Date(cal_y, cal_m + 3, 0, 23, 59, 59);
                    calFilter = { initialStartDate : initial, endStartDate : end };
                    try {
                        pendop = null;
                        pendop = _calendarList[0].findEvents(getEventsCB, _errorOccurred, calFilter);
		    } catch(e) {
		        _catchException(e);
		        pendop = null;
		    }

	            function getEventsCB(events) {
	                _events = events;
                        showCalMainHTML();
                    }
                }

                /* list day-calendar */
                function listCalList() {
                    initial = new Date(cal_y, day_m - 1, day_d, 0, 0, 0);
                    end = new Date(cal_y, day_m - 1, day_d, 23, 59, 59);

                    calFilter = { initialStartDate : initial, endStartDate : end };
                    try {
                        pendop = null;
                        pendop = _calendarList[0].findEvents(getOneDayEventsCB, _errorOccurred, calFilter);
		    } catch(e) {
		        _catchException(e);
		        pendop = null;
		    }

		    function getOneDayEventsCB(events) {
		        _oneDayEvents = events;
                        showCalListHTML();
                    }
                }

                /* list event detail */
                function listCalDetail() {
                    showCalDetailHTML();
                }

                /* show calendar event detail */
                function showCalDetailHTML() {
                    jQuery("#cal_ui_main").hide();
                    jQuery("#cal_ui_list").hide();
                    jQuery("#cal_ui_detail").show("fast");
                }


                /* show calendar List window */
                function showCalListHTML() {
                    jQuery("#cal_list_title").html(day_d + " " + MONTHS_S[day_m-1] + " " + cal_y);
                    nodes = _oneDayEvents;
                    var row_color;
                    var str = "";
                    var d;
                    str += '<table cellpadding="5" id="fs_ui_fileList_tb" width="100%" border="0" cellspacing="0">\n'+
                	'<tr class="list_head"><th width="15%">Time</th><th width="75%">Summary</th>'+
                	'<th width="10%">&nbsp;</tr>';
                    for (var i = 0; i < nodes.length; i++) {
                        if (i%2) {
                            row_color = "eeeeee";
                        }
                        else {
                            row_color = "ffffff";
                        }
	                str += "<tr style='background-color:#" + row_color + "' id='"+ nodes[i].id;
	                str += "'><td id='calDetailCB' align='center'><div class='calTime'>";
	                d = nodes[i].startTime;
	                if (Object.prototype.toString.call(d) === "[object Date]" ) {
	                    if (d.getHours() < 10) {
	                        str += "0";
                            }
	                    str += d.getHours();
	                    str +=":";
	                    if (d.getMinutes() < 10) {
	                        str += "0";
	                    }
	                    str += d.getMinutes();
                        }
                        else
                            str += "&nbsp;";
	                str += "</div></td><td id='calDetailCB'><div class='calSummary'>";
	                str += nodes[i].summary;
	                str += "</div></td>";
                        str += "<td align='center'><input type='checkbox' id='cal_del' value='" + nodes[i].id + "' /></td></tr>";
                    }
	            str += "</table>";
                    jQuery("#available-events-list").html(str);
                    jQuery("#cal_ui_main").hide();
                    jQuery("#cal_ui_list").show("fast");
                    jQuery("#cal_ui_detail").hide();
                }

                /* show calendar main window */
                function showCalMainHTML() {
                    jQuery("#cal_main_title").html(genCalTitle(cal_y, month_page));
                    jQuery("#cal1").html(genCalTable(cal_y, cal_m));
                    jQuery("#cal2").html(genCalTable(cal_y, cal_m+1));
                    jQuery("#cal3").html(genCalTable(cal_y, cal_m+2));
                    jQuery("#cal4").html(genCalTable(cal_y, cal_m+3));
                    jQuery("#cal_ui_main").show();
                    jQuery("#cal_ui_list").hide();
                    jQuery("#cal_ui_detail").hide();

                    for (i = 0; i < _events.length; i++) {
                        t = _events[i].startTime;
                        num = 2 + t.getMonth() - cal_m;
                        tableName = "cal" + num.toString();
                        d = t.getDate();
		        tmpDate = new Date(cal_y, t.getMonth(), 1);
		        firstDay = tmpDate.getDay();
		        row = Math.ceil((d + firstDay) / 7);
		        col = (d + firstDay) - (row - 1) * 7;
		        cell = jQuery("#"+tableName)[0].children[1].children[0].children[0].children[row].children[col-1];
		        cell.innerHTML = "<div><a id='calCB' class='cal_cell_h'>" + d + "</a></div>";
                    }

                    if (now.getFullYear() === cal_y) {
                        if (now.getMonth() >= cal_m - 1 && now.getMonth() <= cal_m + 3) {
                            num = 2 + now.getMonth() - cal_m;
                            tableName = "cal" + num.toString();
                            cell = jQuery("#"+tableName)[0].children[0];
                            cell.innerHTML = "<div class='cal_month_title_H'>" + cell.innerHTML + "</div>";
                            d = now.getDate();
                            tmpDate = new Date(cal_y, now.getMonth(), 1);
                            firstDay = tmpDate.getDay();
                            row = Math.ceil((d + firstDay) / 7);
                            col = (d + firstDay) - (row - 1) * 7;
                            cell = jQuery("#"+tableName)[0].children[1].children[0].children[0].children[row].children[col-1];
                            if (cell.innerHTML.indexOf("cal_cell_h") >= 0) {
                                cell.innerHTML = "<div class='cal_cell_today'><a id='calCB' class='cal_cell_h'>" + d + "</a></div>";
                            } else {
                                cell.innerHTML = "<div class='cal_cell_today'><a id='calCB' style='color:#FFFFFF;'>" + d + "</a></div>";
                            }
                        }
                    }
                }

                function genCalTitle(fullYear, month_page) {
                    var str;
                    str = "<div class='calMainTitle1'>" + fullYear + "</div><div class='calMainTitle2'>";
                    switch (month_page) {
                    case 1:
                        str += "Jan - Apr";
			break;
		    case 2:
			str += "May - Aug";
			break;
		    case 3:
			str += "Sep - Dec";
			break;
		    }
		    str += "</dev>";
		    return str;
	        }

	        function genCalTable(fullYear, month) {
	            var tmpDate, str = "", i, col, row;
		    tmpDate = new Date(fullYear, month-1, 1);
		    firstDay = tmpDate.getDay();
		    tmpDate = new Date(fullYear, month, 0);
		    d_end = tmpDate.getDate();
		    str = "<div align='center' class='cal_month_title'>" + MONTHS_L[month-1] + "</div>";
		    str += "<div><table cellspacing=5px class='cal_t'><tr style='font-weight:bold;'><td align='center'>Sun</td><td align='center'>Mon</td><td align='center'>Tue</td><td align='center'>Wed</td><td align='center'>Thu</td><td align='center'>Fri</td><td align='center'>Sat</td></tr><tr class='caltr'>";
		    for (i = 0; i <= firstDay-1; i++) {
			str += "<td align='center'>&nbsp;</td>";
		    }
		    col = firstDay;
		    row = 1;
		    for (i = 1; i <= d_end; i++) {
			if (col === 7) {
			    str += "</tr><tr class='caltr'>";
			    col = 0; row++;
			}
			str += "<td align='center'><div><a id='calCB'>" + i + "</a></div></td>";
			col++;
		    }
		    for (i = 42 - firstDay - d_end; i > 0 ; i--) {
			if (col === 7) {
			    str += "</tr><tr class='caltr'>";
			    col = 0; row++;
			}
			str += "<td>&nbsp;</td>";
			col++;
		    }
		    str += "</tr></table></div>";
		    return str;
	        }

                /* CALENDAR DEMO initial. Get calendar list */
                function calendarDemoInit() {
                    now = new Date();
                    month_page = Math.ceil(now.getMonth() / 4);
                    cal_y = now.getFullYear();
                    cal_m = (month_page - 1) * 4 + 1;
                    try {
                        pendop = null;
                        pendop = deviceapis.pim.calendar.getCalendars(
		              calendarListCB, _errorOccurred);
                    }
                    catch (e) {
                        _catchException(e);
                        pendop = null;
                    }

                    function calendarListCB (cals) {
                        _calendarList = cals;
                        listCalMain();
                    }
                }

                /* == calendar DEMO start point == */
                calendarDemoInit();

                /* event-handle: last 4 months */
                jQuery("#cal_last").unbind().bind("click", function () {
		    month_page--;
		    if (month_page === 0) {
			cal_y--;
			month_page=3;
		    }
		    cal_m = (month_page - 1) * 4 + 1;
                    listCalMain();
	        });

                /* event-handle: next 4 months */
                jQuery("#cal_next").unbind().bind("click", function () {
                    month_page++;
                    if (month_page === 4) {
			cal_y++;
			month_page=1;
		    }
		    cal_m = (month_page - 1) * 4 + 1;
                    listCalMain();
	        });

                /* event-handle: change the event status */
                jQuery("#calCB").live("click", function () {
                    var id;
                    day_d = jQuery(this)[0].innerText;
                    id = jQuery(this).parent().parent().parent().parent().parent().parent().parent()[0].id;
                    switch (id) {
                    case "cal1":
                        day_m = cal_m;
                        break;
                    case "cal2":
                        day_m = cal_m + 1;
                        break;
                    case "cal3":
                        day_m = cal_m + 2;
                        break;
                    case "cal4":
                        day_m = cal_m + 3;
                        break;
                    }
                    listCalList();
                });

                /* event-handle: back to main window */
                jQuery("#cal_ui_back").unbind().bind("click", function () {
                    listCalMain();
                });

                /* event-handle: create a new event */
                jQuery("#cal_ui_new").unbind().bind("click", function () {
                    try {
                        eventTmp = _calendarList[0].createEvent({});
                    } catch (e) {
                        alert("create event fail:\n" + e);
                        return;
                    }
                    jQuery("#cal_ui_cal_form_title").text("Add Event");
                    jQuery("#cal-update-button").hide();
                    jQuery("#cal-add-button").show();

                    jQuery("#cal-summary").val(eventTmp.summary);
                    jQuery("#cal-location").val(eventTmp.location);
                    d = eventTmp.startTime;
	            if (Object.prototype.toString.call(d) === "[object Date]" ) {
                        jQuery("#cal-hour").val(d.getHours());
                        jQuery("#cal-minute").val(d.getMinutes());
                    }
                    jQuery("#cal-duration").val(eventTmp.duration);
                    jQuery("#cal-description").val(eventTmp.description);
                    listCalDetail();
                });

                /* event-handle: add a event */
                jQuery("#cal-add-button").unbind().bind("click", function () {
                    eventTmp = {};
                    eventTmp.summary = jQuery("#cal-summary").val();
                    eventTmp.location= jQuery("#cal-location").val();
                    h = jQuery("#cal-hour").val();
                    min = jQuery("#cal-minute").val();
                    eventTmp.startTime = new Date(cal_y, day_m - 1, day_d, h, min, 0);
                    eventTmp.duration = parseInt(jQuery("#cal-duration").val(), 10);
                    eventTmp.description = jQuery("#cal-description").val();

                    try {
                        pendop = null;
                        pendop = _calendarList[0].addEvent(eventAddSuccessCB, _errorOccurred, eventTmp);
		    } catch(e) {
		        _catchException(e);
		        eventTmp = {};
		        pendop = null;
                    }
                    listCalList();

                    function eventAddSuccessCB (event) {
                        //alert("event id: " + event.id +" added successfully");
                    };
                });

                /* event-handle: show the specific event detail */
                jQuery("#calDetailCB").live("mousedown", function () {
                    jQuery("#cal_ui_cal_form_title").text("Edit Event");
                    jQuery("#cal-update-button").show();
                    jQuery("#cal-add-button").hide();
                    var item = jQuery(this).parent(), i = 0, id;
                    id = item[0].id;
                    for (i = 0; i < _oneDayEvents.length; i++) {
                        if (_oneDayEvents[i].id === id) {
                            jQuery("#cal-id").val(id);
                            jQuery("#cal-summary").val(_oneDayEvents[i].summary);
                            jQuery("#cal-location").val(_oneDayEvents[i].location);
                            d = _oneDayEvents[i].startTime;
                            if (Object.prototype.toString.call(d) === "[object Date]" ) {
                                jQuery("#cal-hour").val(d.getHours());
                                jQuery("#cal-minute").val(d.getMinutes());
                            }
                            jQuery("#cal-duration").val(_oneDayEvents[i].duration);
                            jQuery("#cal-description").val(_oneDayEvents[i].description);
                        }
                    }
                    listCalDetail();
                });

                /* event-handle: update a event */
                jQuery("#cal-update-button").unbind().bind("click", function () {
                    id = jQuery("#cal-id").val();
                    for ( i = 0; i < _oneDayEvents.length; i++) {
                        if (_oneDayEvents[i].id === id) {
                            eventTmp = {};
                            eventTmp.id = id;
                            eventTmp.summary = jQuery("#cal-summary").val();
                            eventTmp.location= jQuery("#cal-location").val();
                            h = jQuery("#cal-hour").val();
                            min = jQuery("#cal-minute").val();
                            eventTmp.startTime = new Date(cal_y, day_m - 1, day_d, h, min, 0);
                            eventTmp.duration = parseInt(jQuery("#cal-duration").val(), 10);
                            eventTmp.description = jQuery("#cal-description").val();
                            try {
                                pendop = null;
                                pendop = _calendarList[0].updateEvent(function () {listCalList();}, _errorOccurred, eventTmp);
		            } catch(e) {
		                _catchException(e);
		                pendop = null;
                            }
                            break;
                        }
                    }
                });

                /* event-handle: cannel */
                jQuery("#cal-cancel-button").unbind().bind("click", function () {
                    jQuery("#cal_ui_main").hide();
                    jQuery("#cal_ui_list").show();
                    jQuery("#cal_ui_detail").hide();
                });

                /* event-handle: delete events */
                jQuery("#cal_ui_del").unbind().bind("click", function () {
                    dels = [];
                    jQuery(":checkbox").each(function() {
                        if (this.checked) {
                            dels.push(this.value);
                        }
                    });

                    for (i = 0; i < dels.length; i++) {
                        try {
                            pendop = null;
                            pendop = _calendarList[0].deleteEvent(eventDelsCB, _errorOccurred, dels[i]);
		        } catch(e) {
		            _catchException(e);
		            pendop = null;
                        }
                    }

                    function eventDelsCB () {
                        listCalList();
                    }
                });
            },
            
            "camera.html": function () {
                _setNavBackAndHome();
                
                var pendop = null, imgNum = 0,
                    mainCamera, myPreviewId = null;
                
                //retrieve a 'container' node which can house the preview window object
                var cameraContainer = document.getElementById("camera_container");

                //success callback
                function onCamerasObtained(cams) {
                    if(cams.length > 0) {
                        //store main camera
                        mainCamera = cams[0];
                        jQuery("#camera-preview").show();
                        jQuery("#camera-preview-hide").show();
                        jQuery("#camera-image-capture").show();
                        jQuery("#camera-record").show();
                        jQuery("#camera-stop").show();
                        jQuery("#camera-cancel").show();
                        jQuery("#gettingCamera").hide('slow');
                    } else {
                        alert("no cameras found");
                    }
                }

                //call async function to retrieve all cameras on device
                function getCameras() {
                    jQuery("#camera-preview").hide();
                    jQuery("#camera-preview-hide").hide();
                    jQuery("#camera-image-capture").hide();
                    jQuery("#camera-record").hide();
                    jQuery("#camera-stop").hide();
                    jQuery("#camera-cancel").hide();
                    jQuery("#gettingCamera").show('slow');
                    try {
                        pendop = null;
                        pendop = deviceapis.camera.getCameras(
                            onCamerasObtained, _errorOccurred);
                    } catch (e) {
                        _catchException(e);
                        pendop = null;
                    }
                };
                getCameras();

                //success callback
                function onCreatePreviewNodeSuccess(previewObject) {
                    myPreviewId = previewObject.id;
                    cameraContainer.appendChild(previewObject);
                    previewObject.style.visibility = "visible"; //start preview
                }

                //call async function to create camera preview DOM object
                //it is assumed that mainCamera is obtained previous using deviceapis.camera.getCameras
                jQuery("#camera-preview").unbind().bind("click", function () {
                    if (cameraContainer.childElementCount > 0) {
                        alert("preview already started !!");
                        return;
                    }
                    try {
                        pendop = null;
                        pendop = mainCamera.createPreviewNode(
                            onCreatePreviewNodeSuccess, _errorOccurred);
                    } catch(e) {
                        _catchException(e);
                        pendop = null;
                    }
                });


                //to be invoked when the user decides to stop the camera preview
                jQuery("#camera-preview-hide").unbind().bind("mousedown", function () {
                    if(myPreviewId != null) {
                        var preview = document.getElementById(myPreviewId);
                        preview.style.visibility = "hidden"; //stop preview
                        cameraContainer.removeChild(preview);
                        myPreviewId = null;
                    } else {
                        alert("preview already stopped");
                    }
                });
                 
                //success callback
                function onCaptureImageSuccess(filename) {
                    imgNum++;
                    // Add to file
                    jQuery("#file").text(filename);
                    jQuery("#cameraEvent").show('slow');

                    setTimeout(function () {
                        jQuery("#cameraEvent").hide('slow');
                    }, 5000);
                }

                //call async function to capture an image
                // it is assumed that mainCamera is obtained previously
                // using deviceapis.camera.getCameras
                jQuery("#camera-image-capture").unbind().bind("click", function () {                                  
                    try {
                        pendop = null;
                        pendop = mainCamera.captureImage(
                            onCaptureImageSuccess, 
                            _errorOccurred,
                            {destinationFilename:"images-" + imgNum + ".jpg", highRes:true}
                        );
                    } catch(e) {
                        _catchException(e);
                        pendop = null;
                    }
                });
                
                function onCaptureVideoSuccess(filename) {
                    imgNum++;
                    jQuery("#file").text(filename);
                    jQuery("#cameraEvent").show('slow');

                    setTimeout(function () {
                        jQuery("#cameraEvent").hide('slow');
                    }, 5000);
                }

                jQuery("#camera-record").unbind().bind("click", function () {
                    imgNum++;
                    //call async function to start a video capture
                    //it is assumed that mainCamera is obtained previous using deviceapis.camera.getCameras
                    try {
                        pendop = null;
                        pendop = mainCamera.startVideoCapture(
                            onCaptureVideoSuccess,
                            _errorOccurred,
                            {destinationFilename:"videos" + imgNum + ".3gp", highRes:true}
                            );
                    } catch(e) {
                        _catchException(e);
                        pendop = null;
                    }

                    jQuery("#camera-recording-status").text("Recording...");
                    jQuery("#camera-record").attr("disabled", true);
                    jQuery("#camera-record").attr("class", "camera-rec-style-disable");
                    jQuery("#camera-stop").attr("disabled", false);
                    jQuery("#camera-stop").attr("class", "camera-rec-style-enable");
                    jQuery("#camera-cancel").attr("disabled", false);
                    jQuery("#camera-cancel").attr("class", "camera-rec-style-enable");

                });

                
                jQuery("#camera-stop").unbind().bind("click", function () {
                    mainCamera.stopVideoCapture();
                    jQuery("#camera-recording-status").text("");
                    jQuery("#camera-record").attr("disabled", false);
                    jQuery("#camera-record").attr("class", "camera-rec-style-enable");
                    jQuery("#camera-stop").attr("disabled", true);
                    jQuery("#camera-stop").attr("class", "camera-rec-style-disable");
                    jQuery("#camera-cancel").attr("disabled", true);
                    jQuery("#camera-cancel").attr("class", "camera-rec-style-disable");
                });
                    
                //to be invoked when the user decides to cancel the video recording
                jQuery("#camera-cancel").unbind().bind("click", function () {
                    //if the op is null, no outstanding operation
                    if (pendop != null) {
                        if(!pendop.cancel()) {
                            alert("operation cannot be canceled as it's already finished/canceled");
                        }
                    } else {
                        alert("no operation to cancel !");
                    }  
                    jQuery("#camera-recording-status").text("");
                    jQuery("#camera-record").attr("disabled", false);
                    jQuery("#camera-record").attr("class", "camera-rec-style-enable");
                    jQuery("#camera-stop").attr("disabled", true);
                    jQuery("#camera-stop").attr("class", "camera-rec-style-disable");
                    jQuery("#camera-cancel").attr("disabled", true);
                    jQuery("#camera-cancel").attr("class", "camera-rec-style-disable");
                });
            },
       
           "deviceinteraction.html": function () {
                _setNavBackAndHome();  
	            var timeout = null;
	            var di = deviceapis.deviceinteraction;
	            function hideInfo(){
	                if (timeout) clearTimeout(timeout);
                    timeout = null;
                    jQuery("#di-infopanel").hide("slow");
	            }
	            function showInfo(info){
	                jQuery("#infopanel-context").text(info);
	                jQuery("#di-infopanel").show("slow");
                    timeout = setTimeout(hideInfo, 3000);
	            }
	            function showOptionInfo(info){
	                 jQuery("#di-option-info").text(info);
	            }
	            function hideOptionInfo(){
	                jQuery("#di-option-info").text("");
	            }
	            function callback(info){
	                return function(){
	                    showInfo(info);
	                }
	            }
	    
	            jQuery("#di-start-notify").click(function(){
	               di.startNotify(callback("startNofify OK."), callback("No way to notify"), jQuery("#di-duration").val());
	            });
	            jQuery("#di-stop-notify").click(function(){
	               di.stopNotify();
	               showInfo("stopNofify");
	            });
	            jQuery("#di-start-vibrate").click(function(){
	               di.startVibrate(callback("startVibrate OK."), callback("Vibrator is Off or pattern is wrong."), jQuery("#di-duration").val(), jQuery("#di-pattern").val().length>0?jQuery("#di-pattern").val():null);
	            });
	            jQuery("#di-stop-vibrate").click(function(){
	               di.stopVibrate();
	               showInfo("stopVibrate");
	            });
	            
	            jQuery("#di-start-backlight").click(function(){
	               di.lightOn(callback("LightOn OK."), callback("Backlight already on"), jQuery("#di-duration").val());
	            });
	            jQuery("#di-stop-backlight").click(function(){
	               di.lightOff();
	               showInfo("LightOff");
	            });
	            jQuery("#di-set-wallpaper").click(function(){
	               di.setWallpaper(callback("Wallpaper Changed"), callback("Cannot change wallpaper"), jQuery("#di-wallpaper").val());
	            });
	            jQuery("#infopanel-close").click(hideInfo);
	            jQuery("#di-duration").focus(function (){
	                showOptionInfo( "Set the duration of notifications in milliseconds. Duration longer than the bulit-in limit(5 seconds) will be trimed. The null(except in vibration) or zero duration will keep the notification on until the limit is reached or is stopped by user.");
	            });
	            jQuery("#di-duration").blur(hideOptionInfo);
	            jQuery("#di-pattern").focus(function (){
	                showOptionInfo( "Set the pattern of vibration. The pattern string composed by '.' and '_' chars. Where '.' denotes a 'vibration pulse' and '_' denotes a 'no vibration pulse'. The pattern has a limit of 10 characters, and the duration of every pulse should be 100 milliseconds. For instance, the pattern '..__.' denotes that the device should vibrate for 200 msecs, stop vibrating for 200 msecs and vibrate again for 100 msecs. ");
	            });
	            jQuery("#di-pattern").blur(hideOptionInfo);
	                          
            },

            "devicestatus.html": function () {
                _setNavBackAndHome();

                var deviceInfoAspects = ["Battery", "Device", "Display", "MemoryUnit", "OperatingSystem", "WebRuntime"],
                        networkInfoAspects = ["CellularHardware", "CellularNetwork", "WiFiHardware", "WiFiNetwork"],
                        allAspects, isWatching = false, watchIdMap = {};

                allAspects = deviceInfoAspects.concat(networkInfoAspects);

                jQuery("#ds_ui_watch").unbind().bind("click", function () {                    
                    for (index = 0; index < allAspects.length; index++) {
                        var properties = getProperties(allAspects[index]);
                        for (var propertyIndex = 0; propertyIndex < properties.length; propertyIndex++) {
                            var prop = {aspect: allAspects[index], property: properties[propertyIndex]};                
                            clearWatchProperty(prop);                             
                        }
                    }
                    jQuery("#head_unconnected").show(); 
                    jQuery("#head_connected").hide();
                    isWatching = false;                
                });                
            
                jQuery("#ds_ui_unwatch").unbind().bind("click", function () {                    
                    for (index = 0; index < allAspects.length; index++) {
                        var properties = getProperties(allAspects[index]);
                        for (var propertyIndex = 0; propertyIndex < properties.length; propertyIndex++) {
                            var prop = {aspect: allAspects[index], property: properties[propertyIndex]};          
                            watchProperty(prop);                             
                        }
                    }
                    jQuery("#unwatch_all_btn").val("Changed!");
                    jQuery("#head_unconnected").hide(); 
                    jQuery("#head_connected").show();
                    isWatching = true;                   
                });         

                listAllComponents();

                function getProperties(aspect) {
                    var properties = [];
                    switch (aspect) {
                    case "Battery":
                        properties.push("batteryLevel");
                        properties.push("batteryBeingCharged");
                        break;
                    case "CellularHardware":
                        properties.push("status");
                        break;
                    case "CellularNetwork":
                        properties.push("isInRoaming");
                        properties.push("mcc");
                        properties.push("mnc");
                        properties.push("signalStrength");
                        properties.push("operatorName");
                        break;
                    case "Device":
                        properties.push("imei");
                        properties.push("model");
                        properties.push("version");
                        properties.push("vendor");
                        break;
                    case "Display":
                        properties.push("resolutionHeight");
                        properties.push("pixelAspectRatio");
                        properties.push("dpiY");
                        properties.push("resolutionWidth");
                        properties.push("dpiX");
                        properties.push("colorDepth");
                        break;
                    case "MemoryUnit":
                        properties.push("size");
                        properties.push("removable");
                        properties.push("availableSize");
                        break;
                    case "OperatingSystem":
                        properties.push("language");
                        properties.push("version");
                        properties.push("name");
                        properties.push("vendor");
                        break;
                    case "WebRuntime":
                        properties.push("wacVersion");
                        properties.push("supportedImageFormats");
                        properties.push("version");
                        properties.push("name");
                        properties.push("vendor");
                        break;
                    case "WiFiHardware":
                        properties.push("status");
                        break;
                    case "WiFiNetwork":
                        properties.push("ssid");
                        properties.push("signalStrength");
                        properties.push("networkStatus");
                        break;
                    default:
                        properties.push("property not found");
                    }
                    return properties;
                }

                function getPropertiesAndValues(aspect) {
                    var propertiesAndValues = [], properties = [], prop = {}, index;

                    function onSuccess(value, prop) {
                        propertiesAndValues.push({property: prop.property, value: value});
                    }

                    
                    properties = getProperties(aspect);
                    for (index = 0; index < properties.length; index++) {
                        prop.property = properties[index];
                        prop.aspect = aspect;
                        deviceapis.devicestatus.getPropertyValue(onSuccess, _errorOccurred, prop);
                    }

                    return propertiesAndValues;
                }

                function createAspectItem(aspect) {
                    var foldImage = "images/arrow_down.png",
                        unfoldImage = "images/arrow_right.png",
                        imageHideHtml = '<div class="ds_ui_btn"><center><img src=' + unfoldImage + ' width="24" height="24" id="btn' + aspect + '_hide"></center></div>',
                        itemHideHtml = '\n<table id="' + aspect + '_hide" width="100%" border="0" cellspacing="0" cellpadding="3"><tr><td width="10%">' + 
                                            imageHideHtml + '</td>' + '<td width="30%">'+ aspect + '</td><td width="60%">&nbsp;</td></tr></table>\n',
                        imageHtml = '<div class="ds_ui_btn"><center><img src=' + foldImage + ' width="24" height="24" id="btn' + aspect + '"></center></div>',
                        itemHeadHtml = '\n<table id="' + aspect + '_show" width="100%" border="1" cellspacing="0" cellpadding="3" style="DISPLAY: none"><tr><td width="10%">' + imageHtml + '</td>' +
                                       '<td width="30%">'+ aspect + '</td><td width="60%">&nbsp;</td></tr>\n',
                        propertiesAndValues = getPropertiesAndValues(aspect),
                        itemContentHtml = '',
                        itemTailHtml = '</table>\n',
                        index, row_color;

                    for (index = 0; index < propertiesAndValues.length; index++ ) {
                        if (index%2) {
                			row_color = "eeeeee";
                		}
                		else {
                			row_color = "ffffff";
                		}
                        itemContentHtml += '<tr style="background-color:#'+row_color+'"><td width="10%">&nbsp;</td><td width="30%">' + propertiesAndValues[index].property + '</td>' +
                                                 '<td width="60%"><center>' + propertiesAndValues[index].value + '</center></td></tr>';
                    }

                    return itemHideHtml + itemHeadHtml + itemContentHtml + itemTailHtml;
                }

                function bindBtns(aspect) {
                    jQuery("#btn" + aspect).unbind().bind("click", function () {
                        jQuery("#" + aspect + "_show").hide();
                        jQuery("#" + aspect + "_hide").show();
                    });
                    jQuery("#btn" + aspect + "_hide").unbind().bind("click", function () {
                        jQuery("#" + aspect + "_show").show();
                        jQuery("#" + aspect + "_hide").hide();
                    });
                }

                // Should be called after all the html content is created
                function watchProperty(prop) {
                    function watchOnSuccess(value, prop) {                       
                        jQuery("#" + prop.aspect + "_show").remove();
                        jQuery("#" + prop.aspect + "_hide").remove();
                        jQuery("#" + prop.aspect + "_container").append(createAspectItem(prop.aspect));
                        jQuery("#" + prop.aspect + "_show").show();
                        jQuery("#" + prop.aspect + "_hide").hide();
                        bindBtns(prop.aspect);
                    }

                    var options = {
                        minNotificationInterval: 500                     
                    }, wathId;
                    watchId = deviceapis.devicestatus.watchPropertyChange(watchOnSuccess, _errorOccurred, prop, options);
                    watchIdMap[prop.aspect + "." + prop.property] = watchId;                                   
                }
                
                function clearWatchProperty(prop) {   
                    var watchId = watchIdMap[prop.aspect + "." + prop.property];
                    if (watchId) {
                        deviceapis.devicestatus.clearPropertyChange(watchId);
                        jQuery("#" + prop.aspect + "_show").hide();
                        jQuery("#" + prop.aspect + "_hide").show();
                    }
                }
    
                function listAllComponents() {      
                    var index, aspectsHtml='';         
     
                    for (index = 0; index < allAspects.length; index++) {
                        aspectsHtml += '<div id="' + allAspects[index] + '_container">';
                        aspectsHtml += createAspectItem(allAspects[index]);
                        aspectsHtml += "</div>";
                    }

                    jQuery("#ds_ui_aspects_list_container").append(aspectsHtml);
                    for (index = 0; index < allAspects.length; index++) {
                        bindBtns(allAspects[index]);                        
                    }
                }
            },

            "contact.html": function () {
                _setNavBackAndHome();
				var _contact_list = [];
				var _addressbooks = [];

                function contactAddedCB(contact) {
                    //alert('Contact Successfully added');
                    refresh();
                }

                function contactUpdatedCB() {
                    //alert('Contact Successfully updated');
                    refresh();
                }

                function contactDeletedCB() {
                    //alert('Contact Successfully deleted');
                    refresh();
                }
                
                function refreshList() {
                	var i;
                	var table_head = '<table id="contact_ui_List_tb" width="100%" border="0" cellspacing="0" cellpadding="8">\n'+
                					'<tr id="contact_ui_list_head"><th width="10%">&nbsp;</td><td width="30%">&nbsp;Name</th>'+
                					'<th width="40%">Phone Number</th><th width="5%"></th></tr>';
                	var table_tail = '</table>\n';
                	var table_html = table_head;
                	var row_color;
                	var phonenumber;
                	var address;
                	var email;
                	var nickname;
                	var name;
                	
                	for (i = 0; i < _contact_list.length; i++) {
                		if (i%2) {
                			row_color = "eeeeee";
                		}
                		else {
                			row_color = "ffffff";
                		}
                		
                		if (_contact_list[i].phoneNumbers[0] != undefined) {
                			phonenumber = _contact_list[i].phoneNumbers[0].number;
                		}
                		else {
                			phonenumber = "-";
                		}
                		
                		if ((_contact_list[i].lastName == "")&&(_contact_list[i].firstName == "")) {
                			name = "[No name]";
                		}
                		else if (_contact_list[i].lastName == "") {
                			name = _contact_list[i].firstName;
                		}
                		else if (_contact_list[i].firstName == "") {
                			name = _contact_list[i].lastName;
                		}
                		else {
                			name = _contact_list[i].lastName+", "+_contact_list[i].firstName;
                		}
                		
                		table_html += '<tr style="background-color:#'+row_color+'"><td>&nbsp;&nbsp;<img src="images/netbook-contacts.png" width="24" height="24">'+
                		'</td><td>\n<a id="'+ i +'">'+name+
                		'</a></td><td>\n'+phonenumber+'</td><td><input type="checkbox" value="'+_contact_list[i].id+'"></td></tr>';
                	}
                	table_html += table_tail;
                	
                	jQuery("#contact_ui_List_tb").remove();
            		jQuery("#contact_ui_List_tb_container").append(table_html);
            		
            		for (i = 0; i < _contact_list.length; i++) {
            			jQuery("#"+i).unbind().bind("click", function () {
                			var contact_id = jQuery(this).attr("id");
                			if (_contact_list[contact_id].phoneNumbers[0] != undefined) {
                				phonenumber = _contact_list[contact_id].phoneNumbers[0].number;
                			}
                			else {
                				phonenumber = "-";
                			}
                			
                			if (_contact_list[contact_id].addresses[0] != undefined) {
                				address = _contact_list[contact_id].addresses[0].streetAddress;
                			}
                			else {
                				address = "";
                			}
                			
                			if (_contact_list[contact_id].emails[0] != undefined) {
                				email = _contact_list[contact_id].emails[0].email;
                			}
                			else {
                				email = "";
                			}
                			
                			if (_contact_list[contact_id].nicknames[0] != undefined) {
                				nickname = _contact_list[contact_id].nicknames[0];
                			}
                			else {
                				nickname = "";
                			}
                		
                			jQuery("#contact_ui_form_fname").val(_contact_list[contact_id].firstName);
                			jQuery("#contact_ui_form_lname").val(_contact_list[contact_id].lastName);
                			jQuery("#contact_ui_form_nname").val(nickname);
                			jQuery("#contact_ui_form_email").val(email);
                			jQuery("#contact_ui_form_phone").val(phonenumber);
                			jQuery("#contact_ui_form_address").val(address);
                			
                			jQuery("#contact_ui_commit_create_btn").hide();
                			jQuery("#contact_ui_commit_save_btn").show();
                			
                			jQuery("#contact_ui_modifying_id").val(contact_id);
                			jQuery("#contact_ui_contact_form_title").text("Edit Contact");
                			jQuery("#contact_ui_contact_form").show("fast");
                		});
            		}
                }
                
                function GetaddressBooksCB(addressbooks) {
                    if (addressbooks.length > 0) {
                        _addressbooks = addressbooks;
                        getContactList(0);
                    }
                }
                
                function contactListCB(contacts) {
                	_contact_list = [];
                    _contact_list = contacts;
                    refreshList();
                }
                
                function getContactList(num) {
                	 _addressbooks[0].findContacts(contactListCB, _errorOccurred);
                
                }
                
                function refresh() {
                	deviceapis.pim.contact.getAddressBooks(GetaddressBooksCB, _errorOccurred);
                }
                
                jQuery("#contact_ui_add").unbind().bind("click", function () {
                	jQuery("#contact_ui_form_fname").val("");
                	jQuery("#contact_ui_form_lname").val("");
                	jQuery("#contact_ui_form_nname").val("");
                	jQuery("#contact_ui_form_email").val("");
                	jQuery("#contact_ui_form_phone").val("");
                	jQuery("#contact_ui_form_address").val("");
            
                	jQuery("#contact_ui_contact_form_title").text("Add Contact");
                	jQuery("#contact_ui_commit_create_btn").show();
                	jQuery("#contact_ui_commit_save_btn").hide();
                	jQuery("#contact_ui_contact_form").show("fast"); 
                });
                
                
                jQuery("#contact_ui_commit_create_btn").unbind().bind("click", function () {
                	var contact =  _addressbooks[0].createContact(
                        {firstName: jQuery("#contact_ui_form_fname").val(),
                        lastName: jQuery("#contact_ui_form_lname").val(),
                        nicknames: [jQuery("#contact_ui_form_nname").val()],
                        emails: [{email: jQuery("#contact_ui_form_email").val()}],
                        phoneNumbers: [{number: jQuery("#contact_ui_form_phone").val()}],
                        addresses: [{streetAddress:jQuery("#contact_ui_form_address").val(),postalCode:"50013",city:"Zaragoza",country:"ES"},{}]});
                    
                    jQuery("#contact_ui_contact_form").hide();
                    _addressbooks[0].addContact(contactAddedCB, _errorOccurred, contact);
                });
                
                jQuery("#contact_ui_cancel_write_btn").unbind().bind("click", function () {
                	jQuery("#contact_ui_contact_form").hide("fast");
                });
                
                
                jQuery("#contact_ui_delete").unbind().bind("click", function () {
                	
                	jQuery(":checkbox").each(function() {
    					if (this.checked) {
    						//console.log("selected contact ID:", this.value);
    						_addressbooks[0].deleteContact(contactDeletedCB, _errorOccurred, this.value);
    					}
					});
                });
                
                
                jQuery("#contact_ui_commit_save_btn").unbind().bind("click", function () {
                    var modifying_id = jQuery("#contact_ui_modifying_id").val();
                    jQuery("#contact_ui_contact_form").hide("fast");
                          
                    _contact_list[modifying_id].firstName = jQuery("#contact_ui_form_fname").val();
                    _contact_list[modifying_id].lastName = jQuery("#contact_ui_form_lname").val();
                    _contact_list[modifying_id].nicknames[0] = jQuery("#contact_ui_form_nname").val();
                    _contact_list[modifying_id].emails[0].email = jQuery("#contact_ui_form_email").val();
                    _contact_list[modifying_id].phoneNumbers[0] = {number: jQuery("#contact_ui_form_phone").val()};
                    _contact_list[modifying_id].addresses[0] = {streetAddress:jQuery("#contact_ui_form_address").val(),postalCode:"50013",city:"Zaragoza",country:"ES"};
                    
                    _addressbooks[0].updateContact(contactUpdatedCB, _errorOccurred, _contact_list[modifying_id]);
                });
                
                refresh();
                jQuery("#contact_ui_List_tb_container").hide();
                jQuery("#contact_ui_List_tb_container").show("fast");
            },

            "filesystem.html": function () {
                _setNavBackAndHome();
                
                var _command = "";
                var _root_path = "images";
                var _current_path = _root_path;
                var _createFile_filename = "";
                var _deleteFiles = [];
                var _createDir_dirname = "";
                var _deleteDirs = [];
                var _copy_srcFiles = [];
                var _copy_dstFiles = [];
                var _move_srcFiles = [];
                var _move_dstFiles = [];
                var _fileNamelist = [];
                var _fileNamelistbyID = [];
                var _fileTypelistbyID = [];
                var _write_data_type = "";
                var _write_data;
                var _read_data_mode = "";
                var _read_fileSize;
                var _current_opened_file = "";
                var _copy_move_file_list = [];
                var _copy_move_files_dir = "";
                
                
                function success(file) {
                	
                }
                
                function createsuccess(file) {
                	
                };
                function error(file) {
                	
                }
                
                
                function fs_ui_refresh_list(files) {
                	var i;
                	var table_head = '<table cellpadding="5" id="fs_ui_fileList_tb" width="100%" border="0" cellspacing="0">\n'+
                					'<tr class="list_head"><th width="10%">Type</th><th width="40%">Name</th>'+
                					'<th>Size</th><th width="36%">Modified</th><th width="5%"></th></tr>';
                	var table_tail = '</table>\n';
                	var table_html = table_head;
                	var image_html;
                	var row_color;
                	var modified_time;
                	var file_size;
                	var fileID;
                	
                	// Clear old data
                	_fileNamelistbyID = [];
                	_fileTypelistbyID = [];
                	for (i = 0; i < files.length; i++) {
                		if (i%2) {
                			row_color = "eeeeee";
                		}
                		else {
                			row_color = "ffffff";
                		}
                		
                		// For filenames which with " "
                		fileID = "file_id_"+i;
                		_fileNamelistbyID[fileID] = files[i].name;
                		
                		if (files[i].isDirectory) {
                			image_html = '<center><img src="images/user-desktop.png" width="28" height="28"></center>';
                			modified_time = "-";
                			file_size = "-";
                			_fileTypelistbyID[fileID] = "dir";
                		}
                		else {
                			image_html = '<center><img src="images/x-office-document.png"  width="28" height="28"></center>'; 
                			modified_time = files[i].modified;
                			file_size = files[i].fileSize;
                			_fileTypelistbyID[fileID] = "file";
                		}
                		
                		table_html += '<tr style="background-color:#'+ row_color +'"><td>'+image_html+
                			'</td><td>&nbsp;<a id="'+ fileID +'">'+ files[i].name +
                			'</a></td><td>&nbsp;'+ file_size +'</td><td>&nbsp;<font size="-1">'+ modified_time +
                			'</font></td><td>&nbsp;<input name="fileSelectionArray" type="checkbox" value="'+ fileID +'"></td></tr>\n';
            		}
            		table_html += table_tail;
            		
            		jQuery("#fs_ui_fileList_tb").remove();
            		jQuery("#fs_ui_fileList_tb_container").append(table_html);
            		jQuery("#fs_ui_fileList_tb_container").show("fast");
            		
            		for (i = 0; i < files.length; i++) {
            			//fileID = files[i].name.replace(/ /gi, "_");
            			fileID = "file_id_"+i;
            			if (files[i].isDirectory) {
            				//var filename = files[i].name;
                			jQuery("#"+fileID).unbind().bind("click", function () {
                				var file_id = jQuery(this).attr("id");
                				console.log("-->", file_id);
                				
                				if (getdir() == "") {
                					chdir(_fileNamelistbyID[file_id]);
                				}
                				else {
                					chdir(getdir()+"/"+_fileNamelistbyID[file_id]);
                				}
                				jQuery("#fs_ui_fileList_tb_container").hide();
                				listFiles();
                			});
                		}
                		else {
                			jQuery("#"+fileID).unbind().bind("click", function () {
                				var file_id = jQuery(this).attr("id");
                				console.log("-->", file_id);
                				_current_opened_file = _fileNamelistbyID[file_id];
                				read(_fileNamelistbyID[file_id], "");
                			});
                		}
            		}
            		
            		if (files.length > 1) {
            			jQuery("#fs_ui_file_num_text").text(files.length+" files.");
            		}
			else if (files.length == 0) {
				jQuery("#fs_ui_file_num_text").text("0 files.");
			}
            		else {
            			jQuery("#fs_ui_file_num_text").text(files.length+" file.");
            		}
                }
                
                
                function listFilesSuccess(files) {
                	// Clear old data
                	_fileNamelist = [];
                	for (i = 0; i < files.length; i++) {
                		_fileNamelist[i] = files[i].name;
            		}
            		fs_ui_refresh_list(files);
                }
                
                function deleteSuccess() {
                }
                function deleteError(e) {
                	if (e.code == 100) {
                		alert("Delete folder fail: the folder is not empty!");
                	}
                }
                
                function copySuccess() {
                }
                
                function copyError() {
                }
                
                function moveSuccess() {
                }
                
                
                function moveError() {
                }
                
                function readSuccess(str) {
                }
                
                function readError(e) {
                }
                
                function readStreamSuccess(stream) {
                	jQuery("#fs_ui_content_title").text(_current_opened_file);
                	stream.position = 0;
                	jQuery("#fs_ui_filecontent_textarea").val("");
                	//console.log("readStreamSuccess", stream.read(_read_fileSize));
            		jQuery("#fs_ui_filecontent_textarea").val(stream.read(_read_fileSize));
            		jQuery("#fs_ui_fileContent").show("show");
            		stream.close();
                }
                function readStreamError() {
                }
                
                
                function writeStreamSuccess(stream) {
                	if (_write_data_type == "string") {
                		stream.write(_write_data);
                	}
                	else if(_write_data_type == "byte") {
                		stream.writeBytes(_write_data);
                	}
                	else { // base64 data
                		stream.writeBase64(_write_data);
                	}
                	_write_data = "";
                	_write_data_type = "";
            		stream.close();
            		listFiles();
                }
                function writeStreamError() {
                
                }
                
                
                
                function listFiles_resolve_success(file) {
                	file.listFiles(listFilesSuccess, null);
                }   
                function listFiles_resolve_error(file) {
                }
                
                
                function createFile_resolve_success(file) {
                	try {
                		file.createFile(_createFile_filename);
                	} catch (e) {
                		if (e.IO_ERR) {
                    		//_exist = true;
                		}
                	}
                }
                function createFile_resolve_error(file) {
                }
                
                
                function deleteFile_resolve_success(file) {
                	try {
                		for (var i=0; i<_deleteFiles.length; i++) {
                			file.deleteFile(deleteSuccess, deleteError, _deleteFiles[i]);
                		}
                		//file.deleteFile(deleteSuccess, deleteError, "images/abc123/cde.txt");
                	} catch (e) {
                		if (e.IO_ERR) {
                    		//_exist = true;
                		}
                	}
                }   
                function deleteFile_resolve_error(file) {
                }
                
                
                 function createDir_resolve_success(file) {
                	try {
                		file.createDirectory(_createDir_dirname);
                	} catch (e) {
                		if (e.IO_ERR) {
                    		//_exist = true;
                		}
                	}
                }
                function createDir_resolve_error(file) {
                }
                
                
                function deleteDir_resolve_success(file) {
                	try {
                		for (var i=0; i<_deleteDirs.length ; i++) {
                			file.deleteDirectory(deleteSuccess, deleteError, _deleteDirs[i]);
                		}
                		
                		//file.deleteFile(deleteSuccess, deleteError, "images/abc123/cde.txt");
                	} catch (e) {
                		if (e.IO_ERR) {
                    		//_exist = true;
                		}
                	}
                }   
                function deleteDir_resolve_error(file) {
                }
                
                
                function copy_resolve_success(file) {
                	try {
                		for (var i=0; i<_copy_srcFiles.length; i++) {
                			console.log("copy:", _copy_srcFiles[i], _copy_dstFiles[i]);
                			file.copyTo(copySuccess, copyError, _copy_srcFiles[i], _copy_dstFiles[i], true);
                		}
                		
                	} catch (e) {
                		if (e.IO_ERR) {
                    		//_exist = true;
                		}
                	}
                }
                function copy_resolve_error(file) {
                }
                
                function move_resolve_success(file) {
                	try {
                		for (var i=0; i<_move_srcFiles.length; i++) {
                			file.moveTo(moveSuccess, moveError, _move_srcFiles[i], _move_dstFiles[i], true);
                		}
                		
                	} catch (e) {
                		if (e.IO_ERR) {
                    		//_exist = true;
                		}
                	}
                }
                function move_resolve_error(file) {
                }
                
                
                function write_resolve_success(file) {
                	try {
                		file.openStream(writeStreamSuccess, writeStreamError, "w");
                	} catch (e) {
                		if (e.IO_ERR) {
                    		//_exist = true;
                		}
                	}
                }
                function write_resolve_error(file) {
                }
                
                
                function read_resolve_success(file) {
                	try {
                		if (_read_data_mode == "text") {
                			file.readAsText(readSuccess, readError);
                		}
                		else {
                			_read_fileSize = file.fileSize;
                			file.openStream(readStreamSuccess, readStreamError, "r");
                		}
                		_read_data_mode = "";
                	} catch (e) {
                		if (e.IO_ERR) {
                    		//_exist = true;
                		}
                	}
                }
                function read_resolve_error(file) {
                }
                
                
                function listFiles() {
                	deviceapis.filesystem.resolve(listFiles_resolve_success, listFiles_resolve_error, _current_path, "r");
                }
                
                function createFile(filename) {
                	_createFile_filename = filename;
                	deviceapis.filesystem.resolve(createFile_resolve_success, createFile_resolve_error, _current_path, "rw");
                }
                
                function deleteFile(files) {
                	_deleteFiles = [];
                	for (var i=0; i<files.length; i++) {
                		_deleteFiles.push(_current_path + "/" + files[i]);
                	}
                	
                	deviceapis.filesystem.resolve(deleteFile_resolve_success, deleteFile_resolve_error, _current_path, "rw");
                }
                
                
                function createDir(dirname) {
                	_createDir_dirname = dirname;
                	deviceapis.filesystem.resolve(createDir_resolve_success, createDir_resolve_error, _current_path, "rw");
                }
                

                function deleteDir(dirs) {
                	_deleteDirs = [];
                	for (var i=0; i<dirs.length; i++) {
                		_deleteDirs.push(_current_path + "/" + dirs[i]);
                	}
            
                	deviceapis.filesystem.resolve(deleteDir_resolve_success, deleteDir_resolve_error, _current_path, "rw");
                }
                
                
                // TODO:
                function rdeleteDir(dirname) {
                	
                }
                
                function copy(srcFiles, srcDir, dstDir) {
                	_copy_srcFiles = [];
                	_copy_dstFiles = [];
                	for (var i=0; i<srcFiles.length;i++) {
                		if (srcDir == ""||srcDir == "/") {
                			_copy_srcFiles.push(_root_path + "/" + srcFiles[i]);
                		}
                		else {
                			_copy_srcFiles.push(_root_path + "/" + srcDir + "/" + srcFiles[i]);
                		}
                		if (dstDir == ""||srcDir == "/") {
                			_copy_dstFiles.push(_root_path + "/" + srcFiles[i]);
                		}
                		else {
                			_copy_dstFiles.push(_root_path + "/" + dstDir + "/" + srcFiles[i]);
                		}
                	}
                	//_copy_move_file_list = [];
                	//_copy_move_files_dir = "";
                	deviceapis.filesystem.resolve(copy_resolve_success, copy_resolve_error, (_root_path + "/" + srcDir), "rw");
                }
                
                function move(srcFiles, srcDir, dstDir) {
                	_move_srcFiles = [];
                	_move_dstFiles = [];
                	for (var i=0; i<srcFiles.length;i++) {
                		if (srcDir == ""||srcDir == "/") {
                			_move_srcFiles.push(_root_path + "/" + srcFiles[i]);
                		}
                		else {
                			_move_srcFiles.push(_root_path + "/" + srcDir + "/" + srcFiles[i]);
                		}
                		if (dstDir == ""||srcDir == "/") { 
                			_move_dstFiles.push(_root_path + "/" + srcFiles[i]);
                		}
                		else {
                			_move_dstFiles.push(_root_path + "/" + dstDir + "/" + srcFiles[i]);
                		}
                	}
                	_copy_move_file_list = [];
                	_copy_move_files_dir = "";
                	deviceapis.filesystem.resolve(move_resolve_success, move_resolve_error, (_root_path + "/" + srcDir), "rw");
                }
                
                
                function write(File, data, type) {
                	write_File = _current_path + "/" + File;
                	_write_data_type = type;
                	_write_data = data;
                	deviceapis.filesystem.resolve(write_resolve_success, write_resolve_error, write_File, "rw");
                }
                
                
                function read(File, mode) {
                	read_File = _current_path + "/" + File;
                	_read_data_mode = mode;
                	deviceapis.filesystem.resolve(read_resolve_success, read_resolve_error, read_File, "r");
                }
                
                
                function chdir(path) {
                	if (path == "/"||path == "") {
                		_current_path = _root_path;
                	}
                	else {
                		_current_path = _root_path + "/" + path ;
                	}
                }
                
                function getdir() {
                	if (_current_path == _root_path) {
                		return "";
                	}
                	return _current_path.split(_root_path+"/")[1];
                }
                
                
                jQuery("#fs_ui_go_previous").unbind().bind("click", function () {
                	var target_path = "";
                	if (_current_path == _root_path) {
                		return;
                	}
                	else {
                		var abc = _current_path.split(_root_path+"/")[1];
                		var cde = abc.split("/");
                		console.log("cde:", cde);
                		if (cde.length > 1) {
                			for (var i=0; i<cde.length-1;i++) {
                				target_path += cde[i]+"/";
                			}
                			target_path = target_path.substring(0, target_path.length - 1);
                		}
                		else {
                			target_path = "";
                		}
                		
                		chdir(target_path);
                		jQuery("#fs_ui_fileList_tb_container").hide();
                		listFiles();
                	}
                });
                
                // Handle create file
                jQuery("#fs_ui_create_file").unbind().bind("click", function () {
                	jQuery("#fs_ui_dirname_form").hide();
                	jQuery("#fs_ui_filename_form").show("fast");
                });
                
              	jQuery("#fs_ui_cancel_filename_btn").unbind().bind("click", function () {
                	jQuery("#fs_ui_filename_form").hide("fast");
                	jQuery("#fs_ui_wanted_filename").val("");
                });
                
                jQuery("#fs_ui_commit_filename_btn").unbind().bind("click", function () {
                	for (var i = 0; i < _fileNamelist.length; i++) {
                		console.log("filename:", _fileNamelist[i]);
                		if (_fileNamelist[i] ==  jQuery("#fs_ui_wanted_filename").val()) {
                			alert("Filename exists!");
                			return;
                		}
                	}
					createFile(jQuery("#fs_ui_wanted_filename").val());
                	jQuery("#fs_ui_filename_form").hide("fast");
                	jQuery("#fs_ui_wanted_filename").val("");
                	listFiles();
                });
                
                jQuery("#fs_ui_create_dir").unbind().bind("click", function () {
                	jQuery("#fs_ui_filename_form").hide();
                	jQuery("#fs_ui_dirname_form").show("fast");
                });
                
              	jQuery("#fs_ui_cancel_dirname_btn").unbind().bind("click", function () {
                	jQuery("#fs_ui_dirname_form").hide("fast");
                	jQuery("#fs_ui_wanted_dirname").val("");
                });
                
                jQuery("#fs_ui_commit_dirname_btn").unbind().bind("click", function () {
                	for (var i = 0; i < _fileNamelist.length; i++) {
                		console.log("dirname:", _fileNamelist[i]);
                		if (_fileNamelist[i] ==  jQuery("#fs_ui_wanted_dirname").val()) {
                			alert("Folder name exists!");
                			return;
                		}
                	}
                	
					createDir(jQuery("#fs_ui_wanted_dirname").val());
                	jQuery("#fs_ui_dirname_form").hide("fast");
                	jQuery("#fs_ui_wanted_dirname").val("");
                	listFiles();
                });
               
                jQuery("#fs_ui_delete").unbind().bind("click", function () {
                	var delete_files = [];
                	var delete_dirs = [];
                	
                	jQuery(":checkbox").each(function() {
    					if (this.checked) {
    						console.log("selected file type:",_fileTypelistbyID[this.value]);
    						console.log("selected filename:",_fileNamelistbyID[this.value]);
    						if (_fileTypelistbyID[this.value] == "dir") {
    							// TODO: Recurcive delete 
    							//deleteDir(_fileNamelistbyID[this.value]);
    							delete_dirs.push(_fileNamelistbyID[this.value]);
    						}
    						else { // file
    							delete_files.push(_fileNamelistbyID[this.value]); 
    							//deleteFile(_fileNamelistbyID[this.value]);
    						}
    					}
					});
					
					if (delete_files.length > 0) {
						deleteFile(delete_files);
					}
					
					if (delete_dirs.length > 0) {
						deleteDir(delete_dirs);
					}
					
					listFiles();
                });
                
                
                jQuery("#fs_ui_commit_write_btn").unbind().bind("click", function () {
                	write(_current_opened_file, jQuery("#fs_ui_filecontent_textarea").val(), "string");
                	jQuery("#fs_ui_fileContent").hide("fast");
                	jQuery("#fs_ui_filecontent_textarea").val("");
                });
                
                jQuery("#fs_ui_cancel_write_btn").unbind().bind("click", function () {
                	jQuery("#fs_ui_fileContent").hide("fast");
                	jQuery("#fs_ui_filecontent_textarea").val("");
                });
                
                
                
                 jQuery("#fs_ui_copy").unbind().bind("click", function () {
                 	// Clear old data
                 	_copy_move_file_list = [];
                 	_copy_move_files_dir = "";
                 	_copy_move_flag = "copy";
                 	
                 	var selected_dirs = [];
                 	jQuery(":checkbox").each(function() {
    					if (this.checked) {
    						console.log("selected file type:",_fileTypelistbyID[this.value]);
    						console.log("selected filename:",_fileNamelistbyID[this.value]);
    						if (_fileTypelistbyID[this.value] == "file") {
    							_copy_move_file_list.push(_fileNamelistbyID[this.value]);
    						}
    						else { // file
    							selected_dirs.push(_fileNamelistbyID[this.value]); 
    						}
    					}
					});
					
					_copy_move_files_dir = getdir();
					
					if (_copy_move_file_list.length > 1) {
						alert("Copy files: "+_copy_move_file_list.length + " files selected(Folders won't be selected)");
					}
					else {
						alert("Copy file: "+_copy_move_file_list.length + " file selected(Folders won't be selected)");
					}
                 });
                 
                 jQuery("#fs_ui_cut").unbind().bind("click", function () {
                 	// Clear old data
                 	_copy_move_file_list = [];
                 	_copy_move_files_dir = "";
                 	_copy_move_flag = "move";
                 	
                 	var selected_dirs = [];
                 	jQuery(":checkbox").each(function() {
    					if (this.checked) {
    						if (_fileTypelistbyID[this.value] == "file") {
    							_copy_move_file_list.push(_fileNamelistbyID[this.value]);
    						}
    						else { // file
    							selected_dirs.push(_fileNamelistbyID[this.value]); 
    						}
    					}
					});
					
					_copy_move_files_dir = getdir();
					
					if (_copy_move_file_list.length > 1) {
						alert("Move files: "+_copy_move_file_list.length + " files selected(Folders won't be selected)");
					}
					else {
						alert("Move file: "+_copy_move_file_list.length + " file selected(Folders won't be selected)");
					}
                 });
                
                
                jQuery("#fs_ui_paste").unbind().bind("click", function () {
                	
                	if (_copy_move_file_list.length == 0) {
                		alert("No file selected!")
                		return;
                	}
                	
                	if (_copy_move_files_dir == getdir()) {
                		alert("Can't copy/move files: the source and target directory are the same!")
                		return;
                	}
                	if (_copy_move_flag == "copy") {
                		copy(_copy_move_file_list, _copy_move_files_dir, getdir());
                	}
                	if (_copy_move_flag == "move") {
                		move(_copy_move_file_list, _copy_move_files_dir, getdir());
                	}
                	
                	listFiles();
                
                });
               
                listFiles();
            }
        };

    // ----- Private Methods -----
    function _notifyEventWasCalled(message) {
        var eventDiv = jQuery("#eventResult"),
            eventResultDiv;

        if (eventDiv.length > 0) {

            eventResultDiv = eventDiv.children("#eventResultInfo");
            eventDiv
                .show(0, function() {
                    eventResultDiv.html(message);
                })
                .delay(5000)
                .hide(0, function() {
                    eventResultDiv.html("");
                });
        }

    }

    // ----- Public Properties -----
    return {

        setUrl: function(url) {
            _baseUrl = url;
        },
 
        getUrl: function() {
            return _baseUrl;
        },
        
        load: function(view){

            return _routes[view] || null;

        },

        clearHistory: function (){
            _history = [];
        },

        // TODO: add other callback in case callee wants to pass a custom callback not in Routes.
        navigate: function (view, params){

            try{

                if(!view){

                    // if im going back I need to remove myself first
                    _history.pop();

                    var lastView = _history.pop();

                    view = (lastView && lastView[0]) || "index.html";
                    params = (lastView && lastView[2]) || null;

                }
                
                var xhr = new XMLHttpRequest(),
                    callback;

                xhr.onreadystatechange = function (){

                    if(this.readyState === 4) {
                        
                        try{

                            $.UI.loadView(this.responseText);

                            callback = $.Routes.load(view);

                            if (callback){
                                callback.apply(null, params);
                            }

                            $.Routes.historyChanged(view, callback, params);
                            
                        }
                        catch (e){
                            $.Exception.handle(e);
                        }

                    }

                };

                xhr.open("GET", _baseUrl + "html/" + view);

                xhr.send(null);
            }
            catch (e){
                $.Exception.handle(e);
            }

        },
        
        historyChanged: function(view, callback, params){
            _history.push([view, callback, params]);
        }

    };

}(Demo, $));
