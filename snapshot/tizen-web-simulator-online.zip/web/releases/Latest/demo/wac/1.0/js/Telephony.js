(Demo.Telephony = function($, JQuery){

    // public interface
    return {
    };
}(Demo, $));
