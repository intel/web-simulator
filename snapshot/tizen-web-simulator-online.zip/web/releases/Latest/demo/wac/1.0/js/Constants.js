(Demo.Constants = {

	"css": {
		"irrelevant": "irrelevant"
	},

	"common": {
		"view": ".view",
		"viewDirectory": "html/",
		"navLeft": "nav_left",
		"navRight": "nav_right",
		"defaultView": "index.html",
		"headerTitle": ".header h1",
		"header": ".header"
	}

});
