var gamecomplete = false;
var animrow;
var animcol;
var animsub;
var animend;

function rectRun(ra) {
	var aw = ra.w * ra.percent;
	var ah = ra.h * ra.percent;
	var ax = ra.x + (ra.w/2) - (aw/2);
	var ay = ra.y + (ra.h/2) - (ah/2);
	var r = 0;
	var g = (255 * ra.percent)|0;
	var b = 255 - ((155 * ra.percent)|0);
	
	ra.context.fillStyle = "rgba(" + r.toString() + ", " + g.toString() + ", " + b.toString() + ", 0.3)";
	ra.context.clearRect(ax, ay, aw, ah);
	ra.context.fillRect(ax, ay, aw, ah);

	if(ra.percent >= 1.0)
	{
		clearInterval(ra.timer);
		delete ra;
		return;
	}
	
	ra.percent += 0.05;
}

function rectRunRow() {
	rectRun(animrow);
}

function rectRunCol() {
	rectRun(animcol);
}

function rectRunSub() {
	rectRun(animsub);
}

function rectRunEnd() {
	rectRun(animend);
}

function rectAnimator(context, x, y, w, h) {
	this.x = x;
	this.y = y;
	this.w = w;
	this.h = h;
	this.percent = 0;
	this.timer = null;
	this.context = context;
}

function animateRect(context, x, y, w, h, i) {
	if(i == "row")
	{
		animrow = new rectAnimator(context, x, y, w, h);
		animrow.timer = setInterval(rectRunRow, 20)
	}
	else if(i == "col")
	{
		animcol = new rectAnimator(context, x, y, w, h);
		animcol.timer = setInterval(rectRunCol, 20)
	}
	else
	{
		animsub = new rectAnimator(context, x, y, w, h);
		animsub.timer = setInterval(rectRunSub, 20)
	}
}

function drawRect(context, x, y, w, h) {
	context.fillStyle = "rgba(0, 255, 100, 0.3)";
	context.clearRect(x, y, w, h);
	context.fillRect(x, y, w, h);
}

function endGameAnimation(context) {
	animend = new rectAnimator(context, 0, 0, context.canvas.width, context.canvas.height);
	animend.timer = setInterval(rectRunEnd, 20)
}
