// check to see if the value is possible in this cell
function isPossible(idx, val) {

	var i, j;
	// first index in this cell's row
	var rowidx = ((idx / 9)|0)*9;
	// index of this cell's column in the first row
	var colidx = (idx % 9)|0;
	// first index of this cell's 3x3 subgrid
	var subidx = (((rowidx / 27)|0)*27) + (((colidx / 3)|0)*3);
	
	// check the row
	for(i = rowidx; i < (rowidx+9); i++)
		if(i != idx && this.cells[i].value == val)
			return false;
			
	// check the column
	for(i = colidx; i < 81; i+=9)
		if(i != idx && this.cells[i].value == val)
			return false;
			
	// check the 3x3 subgrid
	for(j = subidx; j < subidx+27; j+=9)
		for(i = j; i < j+3; i++)
			if(i != idx && this.cells[i].value == val)
				return false;

	return true;
}

// check to see if a cell's value is legal
function isValidCell(idx) {

	if(this.cells[idx].value == 0)
		return true;
		
	var i, j;
	// first index in this cell's row
	var rowidx = ((idx / 9)|0)*9;
	// index of this cell's column in the first row
	var colidx = (idx % 9)|0;
	// first index of this cell's 3x3 subgrid
	var subidx = (((rowidx / 27)|0)*27) + (((colidx / 3)|0)*3);
	
	// check the row
	for(i = rowidx; i < (rowidx+9); i++)
		if(i != idx && this.cells[i].value == this.cells[idx].value)
			return false;
			
	// check the column
	for(i = colidx; i < 81; i+=9)
		if(i != idx && this.cells[i].value == this.cells[idx].value)
			return false;
			
	// check the 3x3 subgrid
	for(j = subidx; j < subidx+27; j+=9)
		for(i = j; i < j+3; i++)
			if(i != idx && this.cells[i].value == this.cells[idx].value)
				return false;

	return true;
}

function isValidGroup(a, b, c, d, e, f, g, h, i) {

	var checklist = new Array();
	var j;
	for(j = 0; j < 10; j++)
		checklist[j] = false;
	
	checklist[a] = true;
	checklist[b] = true;
	checklist[c] = true;
	checklist[d] = true;
	checklist[e] = true;
	checklist[f] = true;
	checklist[g] = true;
	checklist[h] = true;
	checklist[i] = true;

	// need numbers 1 through 9	
	for(j = 1; j <= 9; j++)
		if(!checklist[j])
			return false;

	return true;
}

// test all cell values and determine which rows, cols, and 3x3 subgrids are valid
function isValidGrid() {

	var i;			
	for(i = 0; i < 9; i++)
	{	
		// check the rows
		this.validrow[i] = isValidGroup(
			this.cells[(i*9)+0].value, this.cells[(i*9)+1].value, this.cells[(i*9)+2].value, 
			this.cells[(i*9)+3].value, this.cells[(i*9)+4].value, this.cells[(i*9)+5].value, 
			this.cells[(i*9)+6].value, this.cells[(i*9)+7].value, this.cells[(i*9)+8].value);			

		// check the columns
		this.validcol[i] = isValidGroup(
			this.cells[i+0].value, this.cells[i+9].value, this.cells[i+18].value, 
			this.cells[i+27].value, this.cells[i+36].value, this.cells[i+45].value, 
			this.cells[i+54].value, this.cells[i+63].value, this.cells[i+72].value);			

		// check the 3x3 subgrids
		this.validsub[i] = isValidGroup(
			this.cells[(((i/3)|0)*27) + ((i%3)*3) + 0].value, 
			this.cells[(((i/3)|0)*27) + ((i%3)*3) + 1].value, 
			this.cells[(((i/3)|0)*27) + ((i%3)*3) + 2].value, 
			this.cells[(((i/3)|0)*27) + ((i%3)*3) + 9].value, 
			this.cells[(((i/3)|0)*27) + ((i%3)*3) + 10].value, 
			this.cells[(((i/3)|0)*27) + ((i%3)*3) + 11].value, 
			this.cells[(((i/3)|0)*27) + ((i%3)*3) + 18].value, 
			this.cells[(((i/3)|0)*27) + ((i%3)*3) + 19].value, 
			this.cells[(((i/3)|0)*27) + ((i%3)*3) + 20].value);
	}
}

// test all cell values and determine which rows, cols, and 3x3 subgrids are valid
function isComplete() {

    var i, victorycounter = 0;
    for(i = 0; i < 9; i++)
    {
        if(this.validrow[i])
        {
            victorycounter++;
        }
        if(this.validcol[i])
        {
            victorycounter++;
        }
        if(this.validsub[i])
        {
            victorycounter++;
        }
    }

    if(victorycounter >= 27)
        gamecomplete = true;
    else
        gamecomplete = false;
}

function setCellValue(idx, value) {

	if(this.cells[idx].fixed)
		return;

	this.cells[idx].value = value;
	this.checkValidGrid();
}

function setFixedCells(number) {

	var numclear = 81 - number;
	var all = new Array();
	var i;
	for(i = 0; i < 81; i++)
		all.push(i);
		
	for(i = 0; i < numclear; i++)
	{
		var target = (Math.random() * all.length)|0;
		var idx = all.splice(target, 1);
		this.cells[idx].fixed = false;
		this.cells[idx].value = 0;
	}
}	

function NumberPlaceCell() {
	this.value = 0;
	this.fixed = true;
	this.possible = new Array();
	for(var i = 0; i < 9; i++)
		this.possible[i] = false;
}

function NumberPlaceGame(difficulty) {

	this.cells = new Array();
	this.validrow = new Array();
	this.validcol = new Array();
	this.validsub = new Array();
	this.prevvalidrow = new Array();
	this.prevvalidcol = new Array();
	this.prevvalidsub = new Array();
	this.checkValidCell = isValidCell;
	this.checkValidGrid = isValidGrid;
	this.checkPossible = isPossible;
	this.checkComplete = isComplete;
	this.setValue = setCellValue;
	this.setFixed = setFixedCells;
	this.ready = false;
	gamecomplete = false;

	var i;
	// all values start out empty
	for(i = 0; i < 81; i++)
		this.cells[i] = new NumberPlaceCell();

	// grid starts out invalid
	for(i = 0; i < 9; i++)
	{
		this.validrow[i] = false;
		this.validcol[i] = false;
		this.validsub[i] = false;
		this.prevvalidrow[i] = false;
		this.prevvalidcol[i] = false;
		this.prevvalidsub[i] = false;
	}
	
	// generate a new numberplace grid
	var gridBuilder = new Array();
	for(i = 0; i < 81; i++)
		gridBuilder[i] = [1,2,3,4,5,6,7,8,9];

	for(i = 0; i < 81; i++)
	{	
		var done = false;
		while(gridBuilder[i].length > 0)
		{
			var test = (Math.random() * gridBuilder[i].length)|0;
			var n = gridBuilder[i].splice(test, 1)[0];
			
			this.cells[i].value = n;
			
			if(this.checkValidCell(i)) 
			{
				done = true;						
				break;
			}
			else
			{
				this.cells[i].value = 0;
				done = false;
				continue;
			}
		}
		
		if(!done)
		{
			gridBuilder[i] = [1,2,3,4,5,6,7,8,9];
			i -= 2;
		}
	}
	this.setFixed(difficulty);
	this.checkValidGrid();	
}
