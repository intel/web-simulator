var option_easyshowsquares = 50;
var option_mediumshowsquares = 40;
var option_hardshowsquares = 30;
var option_showpossible = 1;
var option_flaginvalid = 1;

function readOptions() {
	option_easyshowsquares = localStorage.getItem("easyshowsquares");
	if(option_easyshowsquares <= 0)
	{
		option_easyshowsquares = 50;
		localStorage.setItem("easyshowsquares", option_easyshowsquares);
	}
	option_mediumshowsquares = localStorage.getItem("mediumshowsquares");
	if(option_mediumshowsquares <= 0)
	{
		option_mediumshowsquares = 40;
		localStorage.setItem("mediumshowsquares", option_mediumshowsquares);
	}
	option_hardshowsquares = localStorage.getItem("hardshowsquares");
	if(option_hardshowsquares <= 0)
	{
		option_hardshowsquares = 30;
		localStorage.setItem("hardshowsquares", option_hardshowsquares);
	}
	option_flaginvalid = localStorage.getItem("flaginvalid");
	option_showpossible = localStorage.getItem("showpossible");
}

function easychange() {
	option_easyshowsquares = $("#slidereasy").slider().val();
	localStorage.setItem("easyshowsquares", option_easyshowsquares);
}

function mediumchange() {
	option_mediumshowsquares = $("#slidermedium").slider().val();
	localStorage.setItem("mediumshowsquares", option_mediumshowsquares);
}

function hardchange() {
	option_hardshowsquares = $("#sliderhard").slider().val();
	localStorage.setItem("hardshowsquares", option_hardshowsquares);
}

function flaginvalidchange() {
	option_flaginvalid = ($('input[name=flaginvalid]').is(':checked'))?1:0;
	localStorage.setItem("flaginvalid", option_flaginvalid);
	drawGrid();
}

function showpossiblechange() {
	option_showpossible = ($('input[name=showpossible]').is(':checked'))?1:0;
	localStorage.setItem("showpossible", option_showpossible);
	drawGrid();
}
