

function drawKeypad() {

}

function touchKeypad() {

}

function keypad(context, x, y, h, w) {

	this.context = context;
	this.x = x;
	this.y = y;
	this.h = h;
	this.w = w;
	this.draw = drawKeypad;
	this.touch = touchKeypad;
}
