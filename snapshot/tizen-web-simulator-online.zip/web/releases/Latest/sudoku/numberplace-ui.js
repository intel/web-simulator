var boardCanvas;
var boardContext;
var topCanvas;
var topContext;
var bottomCanvas;
var bottomContext;
var boardWidth;
var screenWidth;
var screenHeight;
var deviceWidth;
var deviceHeight;
var cellSelected = -1;
var pickerMode = 0;
var game;
var audioList = [];
var gamecomplete = false;
var enddialog;

function errorOccured(errorString) {

}

function debugOutput(str) {
    boardContext.clearRect(0, 0, boardWidth, 100);
    boardContext.fillStyle = "black";
    boardContext.fillText(str, 0, 40);
}

function drawGrid() {

    game.checkComplete();
    cellSelected = -1;
    var height = $(window).height() - $("#content").position().top - 1;

    jQuery("#content").height(height); 
    
    screenWidth = $(window).width() - 1;
    screenHeight = height;
    
    if(screenWidth <= screenHeight)
        boardWidth = screenWidth;
    else
        boardWidth = screenHeight;
    
    var x = (screenWidth - boardWidth) / 2
    var y = (screenHeight - boardWidth) / 2

    bottomContext.canvas.width = screenWidth;
    bottomContext.canvas.height = screenHeight;
    boardContext.canvas.width = screenWidth;
    boardContext.canvas.height = screenHeight;
    topContext.canvas.width = screenWidth;
    topContext.canvas.height = screenHeight;

    bottomContext.clearRect(0, 0, bottomContext.canvas.width, bottomContext.canvas.height);
    boardContext.clearRect(0, 0, boardContext.canvas.width, boardContext.canvas.height);
    topContext.clearRect(0, 0, topContext.canvas.width, topContext.canvas.height);

    var i, j;
    var xBmin = (screenWidth - boardWidth) / 2;
    var yBmin = (screenHeight - boardWidth) / 2;
    var m = boardWidth/3;
    var s = boardWidth/9;
    var t = boardWidth/27;
    var textSize = (s*3/4)|0;
    var miniSize = (textSize/3)|0;
    
    // draw the board sized square
    boardContext.lineWidth=10;
    boardContext.strokeStyle = "#000000";
    boardContext.strokeRect(x, y, boardWidth, boardWidth);

    // draw valid row/col/3x3 highlights
    boardContext.fillStyle = "rgba(0, 255, 100, 0.3)";
    var minorvictory = false;

    for(i = 0; i < 9; i++)
    {
        if(game.validrow[i])
        {
            if(game.prevvalidrow[i]||!game.ready||gamecomplete)
            {
                drawRect(bottomContext, xBmin, yBmin+(i*s), boardWidth, s);
            }
            else
            {
                minorvictory = true;
                animateRect(bottomContext, xBmin, yBmin+(i*s), boardWidth, s, "row");
            }
        }
        game.prevvalidrow[i] = game.validrow[i];
        if(game.validcol[i])
        {
            if(game.prevvalidcol[i]||!game.ready||gamecomplete)
            {
                drawRect(bottomContext, xBmin+(i*s), yBmin, s, boardWidth);
            }
            else
            {
                minorvictory = true;
                animateRect(bottomContext, xBmin+(i*s), yBmin, s, boardWidth, "col");
            }
        }
        game.prevvalidcol[i] = game.validcol[i];
        if(game.validsub[i])
        {
            if(game.prevvalidsub[i]||!game.ready||gamecomplete)
            {
                drawRect(bottomContext, xBmin+((i%3)*m), yBmin+(((i/3)|0)*m), m, m);
            }
            else
            {
                minorvictory = true;
                animateRect(bottomContext, xBmin+((i%3)*m), yBmin+(((i/3)|0)*m), m, m, "sub");
            }
        }
        game.prevvalidsub[i] = game.validsub[i];
    }

    if(gamecomplete)
    {
        // game is complete
        audioList[5].play();
	endGameAnimation(bottomContext);
        enddialog.dialog('open');
    }
    else if(minorvictory)
    {
        audioList[3].play();
    }

    // draw all 81 little squares
    boardContext.lineWidth=1;
    for(i = 0; i < 9; i++)
    {
        for(j = 0; j < 9; j++)
        {
            boardContext.strokeRect(x+(j*s), y+(i*s), s, s);
        }
    }
    
    // draw 9 medium squares
    boardContext.lineWidth=4;
    for(i = 0; i < 3; i++)
    {
        for(j = 0; j < 3; j++)
        {
            boardContext.strokeRect(x+(j*m), y+(i*m), m, m);
        }
    }

    // fill in the numbers        
    for(i = 0; i < 81; i++)
    {
        if(game.cells[i].value != 0)
        {        
            boardContext.font = textSize.toString() + "px sans-serif";
            if(game.cells[i].fixed)
                boardContext.fillStyle = "green";
            else if((option_flaginvalid == 1) && !game.checkValidCell(i))
                boardContext.fillStyle = "red";
            else
                boardContext.fillStyle = "black";
            
            var tDim = boardContext.measureText(game.cells[i].value.toString());
            var xOffset = (((i % 9)|0) * s) + (s/2) - ((tDim.width)/2);
            var yOffset = (((i / 9)|0) * s) + (s*3/4);
            boardContext.fillText(game.cells[i].value.toString(), x+xOffset, y+yOffset);
        }
        else if(option_showpossible == 1)
        {
            boardContext.font = miniSize.toString() + "px sans-serif";
            boardContext.fillStyle = "blue";
            for(j = 0; j < 9; j++)
            {
                if(!game.checkPossible(i, j+1))
                    continue;
                var tDim = boardContext.measureText((j+1).toString());
                var xOffset = (((i % 9)|0) * s) + (((j % 3)|0) * t) + (s/6) - ((tDim.width)/2);
                var yOffset = (((i / 9)|0) * s) + (((j / 3)|0) * t) + (s/4);
                boardContext.fillText((j+1).toString(), x+xOffset, y+yOffset);                        
            }
        }
        else
        {
            boardContext.font = miniSize.toString() + "px sans-serif";
            boardContext.fillStyle = "black";
            for(j = 0; j < 9; j++)
            {
                if(!game.cells[i].possible[j])
                    continue;

                if((option_flaginvalid == 1) && !game.checkPossible(i, j+1))
                    boardContext.fillStyle = "red";
                else
                    boardContext.fillStyle = "black";

                var tDim = boardContext.measureText((j+1).toString());
                var xOffset = (((i % 9)|0) * s) + (((j % 3)|0) * t) + (s/6) - ((tDim.width)/2);
                var yOffset = (((i / 9)|0) * s) + (((j / 3)|0) * t) + (s/4);
                boardContext.fillText((j+1).toString(), x+xOffset, y+yOffset);                        
            }
        }
    }
}

function drawPicker(event) {
    
    // clear the whole canvas first
    topContext.clearRect(0, 0, topContext.canvas.width, topContext.canvas.height);

    // calculate the board, touch, and cell coordinates
    var xBmin = (screenWidth - boardWidth) / 2;
    var yBmin = (screenHeight - boardWidth) / 2;
    var bWidth = boardWidth/3;
    var cWidth = boardWidth/9;
    var xCell;
    var yCell;
    var c;

    if(cellSelected < 0)
    {
        pickerMode = event.isPressAndHold ? 1 : 0;
        xCell = event.offsetX - ((event.offsetX - xBmin) % cWidth);
        yCell = event.offsetY - ((event.offsetY - yBmin) % cWidth);
        c = ((((yCell-yBmin+1)/cWidth)*9) + ((xCell-xBmin+1)/cWidth))|0;

        // check to be sure the cell is selectable
        if((c < 0)||(c >= 81)||game.cells[c].fixed)
            return;

        audioList[pickerMode].play();
        cellSelected = c;
    }
    else
    {
        xCell = xBmin + ((cellSelected%9)*cWidth);
        yCell = yBmin + (((cellSelected/9)|0)*cWidth);
        c = cellSelected;
    }

    // draw a rectangle around the whole board
    topContext.lineWidth=10;
    topContext.strokeStyle = (pickerMode)?"#ff00ff":"#ff0000";
    topContext.strokeRect(xBmin, yBmin, boardWidth, boardWidth);
    
    // calculate the text size of the picker numbers, they should be big
    var i;
    var textSize = (bWidth*3/4)|0;
    topContext.font = textSize.toString() + "px sans-serif";
    
    topContext.fillStyle = (pickerMode)?"rgba(200, 0, 200, 0.9)":"rgba(200, 0, 0, 0.9)";
    topContext.strokeRect(xBmin, yBmin, boardWidth, boardWidth);
    // Draw the button squares
    for(i = 0; i < 9; i++)
    {
        topContext.fillStyle = (pickerMode)?((game.cells[c].possible[i])?"rgba(200, 0, 200, 0.5)":"rgba(100, 0, 100, 0.5)"):"rgba(200, 0, 0, 0.5)";
        topContext.fillRect(xBmin + (bWidth*(i%3)), yBmin + (bWidth*((i/3)|0)), bWidth, bWidth);
    }

    // Redraw the selected cell so it stands out        
    topContext.clearRect(xCell, yCell, cWidth, cWidth);
    topContext.lineWidth=4;
    topContext.strokeStyle = (pickerMode)?"#ff00ff":"#ff0000";
    topContext.strokeRect(xCell, yCell, cWidth, cWidth);
    topContext.fillStyle = "rgba(200, 0, 0, 0.3)";
    topContext.fillRect(xCell, yCell, cWidth, cWidth);
    
    // Draw the numbers on each of the buttons
    topContext.fillStyle = (pickerMode)?"rgba(255, 255, 255, 0.6)":"rgba(255, 255, 255, 0.6)";
    for(i = 0; i < 9; i++)
    {
        var num = (i+1).toString();
        var tDim = topContext.measureText(num);
        var xOffset = (bWidth/2) - (tDim.width/2);
        var yOffset = (bWidth*3/4);
        topContext.fillText(num, xBmin + (bWidth*(i%3)) + xOffset, yBmin + (bWidth*((i/3)|0)) + yOffset);
    }
}

function handlePicker(event) {

    // calculate the board, touch, and cell coordinates
    var xBmin = (screenWidth - boardWidth) / 2;
    var yBmin = (screenHeight - boardWidth) / 2;
    var cWidth = boardWidth/3;
    var xCell = event.offsetX - ((event.offsetX - xBmin) % cWidth);
    var yCell = event.offsetY - ((event.offsetY - yBmin) % cWidth);
    var num = (((yCell-yBmin+1)/cWidth)*3 + ((xCell-xBmin+1)/cWidth) + 1)|0;

    audioList[2].play();
    if(pickerMode == 0)
    {
        game.setValue(cellSelected, num);
        
        // clear the whole canvas first
        topContext.clearRect(0, 0, topContext.canvas.width, topContext.canvas.height);
        cellSelected = -1;
        drawGrid();
    }
    else
    {
        game.cells[cellSelected].possible[num-1] = !game.cells[cellSelected].possible[num-1];

        drawPicker(event);
    }
}

var ignoreMouseUp = false;
var mouseTimeout;
function onMouseDown(event) {
    mouseTimeout = setTimeout(function () {
        event.isPressAndHold = true;
        onMouseUp(event);
        ignoreMouseUp = true;
    }, 200);
}

function onMouseUp(event) {
    clearTimeout(mouseTimeout);

    if (ignoreMouseUp) {
        ignoreMouseUp = false;
        return;
    }

    // calculate the board dimensions
    var xBmin = (screenWidth - boardWidth) / 2;
    var yBmin = (screenHeight - boardWidth) / 2;
    var xBmax = xBmin + boardWidth;
    var yBmax = yBmin + boardWidth;

    // if this touch happened on the board
    if((event.offsetX >= xBmin)&&(event.offsetX <= xBmax)&&
       (event.offsetY >= yBmin)&&(event.offsetY <= yBmax))
    {
        if(cellSelected < 0)
            drawPicker(event);
        else
            handlePicker(event);
    }
    else
    {
        topContext.clearRect(0, 0, topContext.canvas.width, topContext.canvas.height);
        if(cellSelected >= 0)
        {
            if(pickerMode == 0)
                game.setValue(cellSelected, 0);
            cellSelected = -1;
            drawGrid();                        
        }
    }
}

function game_start() {

    audioList[4].play();
    game = new NumberPlaceGame(option_easyshowsquares);
    bottomCanvas = document.getElementById("bottomcanvas");
    boardCanvas = document.getElementById("gridcanvas");
    topCanvas = document.getElementById("topcanvas");

    if (!boardCanvas.getContext('2d') || !topCanvas.getContext('2d'))
    {
        errorOccured("Couldn't retrieve context from canvas");
        return;
    }
    bottomContext = bottomCanvas.getContext('2d');
    boardContext = boardCanvas.getContext('2d');
    topContext = topCanvas.getContext('2d');

    drawGrid();
    $(window).bind('resize', drawGrid);
    

    topCanvas.addEventListener('mousedown', onMouseDown);
    topCanvas.addEventListener('mouseup', onMouseUp);
    game.ready = true;
}

function game_restart(numcells) {
    audioList[4].play();
    game = new NumberPlaceGame(numcells);
    drawGrid();
    game.ready = true;
}

$(document).ready(function () {
    readOptions();

    var audiofiles = [
        'menu1.wav',
        'menu2.wav',
        'buttonclick.wav',
        'rowsuccess.wav',
        'beginning.wav',
        'ending.wav'
    ];

    for(var i = 0; i < audiofiles.length; i++) {
        var a = new Audio(audiofiles[i]);
        a.load();
        audioList.push(a);
    }

    $('#easyButton').click(function () {
        game_restart(option_easyshowsquares);
    });
    $('#mediumButton').click(function () {
        game_restart(option_mediumshowsquares);
    });
    $('#hardButton').click(function () {
        game_restart(option_hardshowsquares);
    });
    $('#easyButton2').click(function () {
        enddialog.dialog('close');
        game_restart(option_easyshowsquares);
    });
    $('#mediumButton2').click(function () {
        enddialog.dialog('close');
        game_restart(option_mediumshowsquares);
    });
    $('#hardButton2').click(function () {
        enddialog.dialog('close');
        game_restart(option_hardshowsquares);
    });

    var $dialog = $('#options')
        .dialog({
            autoOpen: false,
            title: 'Game Options',
            modal: true
        });

    var $helpdialog = $('#helpScreen')
        .dialog({
            autoOpen: false,
            title: 'Help',
            modal: true,
            width: "60%"
        });

    enddialog = $('#gameover')
        .dialog({
            autoOpen: false,
            title: 'YOU WIN!!! Play Another?',
            modal: true
        });

    $('#optionsButton').click(function() {
        $dialog.dialog('open');
        // prevent the default action, e.g., following a link
        return false;
    });

    $('#helpButton').click(function() {
        $helpdialog.dialog('open');
        // prevent the default action, e.g., following a link
        return false;
    });

    $("#slidereasy").slider().val(option_easyshowsquares).slider("refresh"); 
    $("#slidermedium").slider().val(option_mediumshowsquares).slider("refresh"); 
    $("#sliderhard").slider().val(option_hardshowsquares).slider("refresh");
    $('input[name=flaginvalid]').attr('checked', (option_flaginvalid == 1));
    $('input[name=showpossible]').attr('checked', (option_showpossible == 1));
    
    game_start();
});
