# LaTeX2HTML 2008 (1.71)
# Associate internals original text with physical files.


$key = q/fig:webFrameArch/;
$ref_files{$key} = "$dir".q|node5.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:webSimulator/;
$ref_files{$key} = "$dir".q|node8.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:webRuntime/;
$ref_files{$key} = "$dir".q|node9.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:nativeSimulator/;
$ref_files{$key} = "$dir".q|node10.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:simulatorRuntime/;
$ref_files{$key} = "$dir".q|node18.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:simulatorComponents/;
$ref_files{$key} = "$dir".q|node6.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:webSimulator/;
$ref_files{$key} = "$dir".q|node16.html|; 
$noresave{$key} = "$nosave";

1;

