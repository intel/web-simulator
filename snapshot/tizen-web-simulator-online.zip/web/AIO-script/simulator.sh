CUR=$(cd $(dirname $0) && pwd)
if [ "$1" == "" ];then
    APP=./demo/wac/2.0/index.html
else
    APP=$1
fi
$CUR/tizen-sdk-wrt.sh file://$CUR/index.html?url=$APP 
